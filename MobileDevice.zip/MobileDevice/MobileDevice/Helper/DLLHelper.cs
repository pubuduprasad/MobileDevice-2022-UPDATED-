﻿using System;
using System.IO;
using Microsoft.Win32;

namespace MobileDevice.Helper
{
	// Token: 0x0200000A RID: 10
	public class DLLHelper
	{
		// Token: 0x060000F3 RID: 243 RVA: 0x00004880 File Offset: 0x00002A80
		public static string GetiTunesMobileDeviceDllPath()
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Apple Inc.\\Apple Mobile Device Support\\Shared");
			bool flag = registryKey != null;
			if (flag)
			{
				string text = registryKey.GetValue("iTunesMobileDeviceDLL") as string;
				bool flag2 = !string.IsNullOrWhiteSpace(text);
				if (flag2)
				{
					FileInfo fileInfo = new FileInfo(text);
					bool exists = fileInfo.Exists;
					if (exists)
					{
						return fileInfo.DirectoryName;
					}
				}
			}
			string text2 = Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles) + "\\Apple\\Mobile Device Support";
			bool flag3 = File.Exists(text2 + "\\iTunesMobileDevice.dll");
			string result;
			if (flag3)
			{
				result = text2;
			}
			else
			{
				text2 = Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFilesX86) + "\\Apple\\Mobile Device Support";
				bool flag4 = File.Exists(text2 + "\\iTunesMobileDevice.dll");
				if (flag4)
				{
					result = text2;
				}
				else
				{
					result = string.Empty;
				}
			}
			return result;
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00004954 File Offset: 0x00002B54
		public static string GetAppleApplicationSupportFolder()
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Apple Inc.\\Apple Application Support");
			bool flag = registryKey != null;
			if (flag)
			{
				string text = registryKey.GetValue("InstallDir") as string;
				bool flag2 = !string.IsNullOrWhiteSpace(text);
				if (flag2)
				{
					return text;
				}
			}
			string text2 = Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles) + "\\Apple\\Apple Application Support\\";
			bool flag3 = !File.Exists(text2 + "\\CoreFoundation.dll");
			string result;
			if (flag3)
			{
				result = text2;
			}
			else
			{
				text2 = Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFilesX86) + "\\Apple\\Apple Application Support\\";
				bool flag4 = !File.Exists(text2 + "\\CoreFoundation.dll");
				if (flag4)
				{
					result = text2;
				}
				else
				{
					result = string.Empty;
				}
			}
			return result;
		}
	}
}
