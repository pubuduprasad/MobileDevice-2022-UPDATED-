﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevice
{
    public class iTunesHelper
	{
		public static RegistryKey OpenRegistryPath(RegistryKey root, string s)
		{
			s = s.Remove(0, 1) + "\\";
			if (root != null)
			{
				while (s.IndexOf("\\") != -1)
				{
					if (root == null)
					{
						break;
					}
					root = root.OpenSubKey(s.Substring(0, s.IndexOf("\\")));
					s = s.Remove(0, s.IndexOf("\\") + 1);
				}
			}
			else
			{
				return null;
			}
			return root;
		}
		public static string GetMobileBackup()
		{
			object obj = null;
			try
			{
				obj = Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Apple Inc.\\Apple Mobile Device Support\\Shared", "AirTrafficHostDLL", null);
			}
			catch
			{
				obj = null;
			}
			string array;
			if (obj != null)
			{
				string text = obj.ToString();
				if (!string.IsNullOrEmpty(text))
				{
					array = text.Replace("AirTrafficHost.dll", "AppleMobileBackup.exe");
					if (!File.Exists(array))
					{
						array = array.Replace("Program Files", "Program Files (x86)");
					}
				}
				else
				{
					array = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFilesX86), "Apple\\Mobile Device Support\\AppleMobileBackup.exe");
				}
			}
			else
			{
				array = null;
			}
			return array;
		}
	}
}
