﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using MobileDevice.Callback;
using MobileDevice.CoreFundation;
using MobileDevice.Enumerates;
using MobileDevice.Helper;

namespace MobileDevice
{
	internal class MobileDevice
	{
		static MobileDevice()
		{
			string text = DLLHelper.GetiTunesMobileDeviceDllPath();
			string appleApplicationSupportFolder = DLLHelper.GetAppleApplicationSupportFolder();
			bool flag = !string.IsNullOrWhiteSpace(text) && !string.IsNullOrWhiteSpace(appleApplicationSupportFolder);
			if (flag)
			{
				Environment.SetEnvironmentVariable("Path", string.Join(";", new string[]
				{
					Environment.GetEnvironmentVariable("Path"),
					text,
					appleApplicationSupportFolder
				}));
			}
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCConnectionClose(IntPtr conn);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCConnectionGetFSBlockSize(IntPtr conn);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCConnectionInvalidate(IntPtr conn);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCConnectionIsValid(IntPtr conn);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCConnectionSetSecureContext(IntPtr device, IntPtr intResult);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCConnectionOpen(int socket, uint io_timeout, ref IntPtr conn);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCDeviceInfoOpen(IntPtr conn, ref IntPtr dict);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceInstallApplication(int socket, IntPtr path, IntPtr options, IntPtr callback, IntPtr unknow1);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceTransferApplication(int socket, IntPtr path, IntPtr options, DeviceInstallApplicationCallback callback, IntPtr unknow1);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceUninstallApplication(IntPtr conn, IntPtr bundleIdentifier, IntPtr installOption, IntPtr unknown0, IntPtr unknown1);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceArchiveApplication(IntPtr conn, IntPtr bundleIdentifier, IntPtr options, DeviceInstallApplicationCallback callback);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDPostNotification(int socket, IntPtr NoticeMessage, uint uint_0);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDObserveNotification(int socket, IntPtr NoticeMessage);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceSecureStartService(IntPtr device, IntPtr service_name, IntPtr unknown, ref IntPtr socket);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDServiceConnectionGetSocket(IntPtr socket);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDServiceConnectionGetSecureIOContext(IntPtr socket);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceLookupApplicationArchives(IntPtr conn, IntPtr AppType, ref IntPtr result);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceLookupApplications(IntPtr conn, IntPtr AppType, ref IntPtr result);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCDirectoryClose(IntPtr conn, IntPtr dir);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCDirectoryCreate(IntPtr conn, string path);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefLock(IntPtr conn, long long_0);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCDirectoryOpen(IntPtr conn, byte[] path, ref IntPtr dir);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCDirectoryOpen(IntPtr afcHandle, IntPtr path, ref IntPtr dir);

		public static int AFCDirectoryOpen(IntPtr conn, string path, ref IntPtr dir)
		{
			return MobileDevice.AFCDirectoryOpen(conn, Encoding.UTF8.GetBytes(path), ref dir);
		}
		public static int AFCDirectoryRead(IntPtr conn, IntPtr dir, ref string buffer)
		{
			IntPtr zero = IntPtr.Zero;
			int num = MobileDevice.AFCDirectoryRead(conn, dir, ref zero);
			bool flag = num == 0 && zero != IntPtr.Zero;
			int result;
			if (flag)
			{
				int num2 = 0;
				List<byte> list = new List<byte>();
				while (Marshal.ReadByte(zero, num2) > 0)
				{
					list.Add(Marshal.ReadByte(zero, num2));
					num2++;
				}
				buffer = Encoding.UTF8.GetString(list.ToArray());
				result = num;
			}
			else
			{
				buffer = null;
				result = num;
			}
			return result;
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCGetFileInfo(IntPtr afcHandle, IntPtr path, ref IntPtr buffer, ref uint length);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCDirectoryRead(IntPtr afcHandle, IntPtr dir, ref IntPtr dirent);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileInfoOpen(IntPtr conn, byte[] path, ref IntPtr dict);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCFileInfoOpen(IntPtr afcHandle, IntPtr path, ref IntPtr info);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefClose(IntPtr conn, long handle);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefOpen(IntPtr conn, byte[] path, int mode, ref long handle);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCFileRefOpen(IntPtr afcHandle, IntPtr path, int mode, ref long handle);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefRead(IntPtr conn, long handle, byte[] buffer, ref uint len);

		// Token: 0x0600005D RID: 93
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefSeek(IntPtr conn, long handle, uint pos, uint origin);

		// Token: 0x0600005E RID: 94
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCFileRefSeek(IntPtr afcHandle, long handle, long pos, uint origin);

		// Token: 0x0600005F RID: 95
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCFileRefUnlock(IntPtr afcHandle, long handle);

		// Token: 0x06000060 RID: 96
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefSetFileSize(IntPtr conn, long handle, uint size);

		// Token: 0x06000061 RID: 97
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefTell(IntPtr conn, long handle, ref uint position);

		// Token: 0x06000062 RID: 98
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFileRefWrite(IntPtr conn, long handle, byte[] buffer, uint len);

		// Token: 0x06000063 RID: 99
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCFlushData(IntPtr conn, long handle);

		// Token: 0x06000064 RID: 100
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCKeyValueClose(IntPtr dict);

		// Token: 0x06000065 RID: 101
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCKeyValueRead(IntPtr dict, ref IntPtr key, ref IntPtr val);

		// Token: 0x06000066 RID: 102
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCRemovePath(IntPtr conn, byte[] path);

		// Token: 0x06000067 RID: 103
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AFCRemovePath(IntPtr afcHandle, IntPtr path);

		// Token: 0x06000068 RID: 104
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AFCRenamePath(IntPtr conn, byte[] old_path, byte[] new_path);

		// Token: 0x06000069 RID: 105
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceActivate(IntPtr device);

		// Token: 0x0600006A RID: 106
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceConnect(IntPtr device);

		// Token: 0x0600006B RID: 107
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr AMDeviceCopyDeviceIdentifier(IntPtr device);

		// Token: 0x0600006C RID: 108 RVA: 0x00003B7C File Offset: 0x00001D7C
		public static object AMDeviceCopyValue(IntPtr device, string domain, string name)
		{
			object result = string.Empty;
			IntPtr intPtr = CoreFoundation.StringToCFString(domain);
			IntPtr intPtr2 = CoreFoundation.StringToCFString(name);
			IntPtr intPtr3 = MobileDevice.AMDeviceCopyValue_Int(device, intPtr, intPtr2);
			bool flag = intPtr != IntPtr.Zero;
			if (flag)
			{
				CoreFoundation.CFRelease(intPtr);
			}
			bool flag2 = intPtr2 != IntPtr.Zero;
			if (flag2)
			{
				CoreFoundation.CFRelease(intPtr2);
			}
			bool flag3 = intPtr3 != IntPtr.Zero;
			if (flag3)
			{
				result = RuntimeHelpers.GetObjectValue(CoreFoundation.ManagedTypeFromCFType(ref intPtr3));
				CoreFoundation.CFRelease(intPtr3);
			}
			return result;
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "AMDeviceCopyValue")]
		public static extern IntPtr AMDeviceCopyValue_Int(IntPtr device, IntPtr domain, IntPtr cfstring);

		public static bool AMDeviceRemoveValue(IntPtr device, string domain, string name)
		{
			bool result = true;
			try
			{
				IntPtr intPtr = CoreFoundation.StringToCFString(domain);
				IntPtr intPtr2 = CoreFoundation.StringToCFString(name);
				bool flag = MobileDevice.AMDeviceRemoveValue_UInt32(device, intPtr, intPtr2) != 0;
				if (flag)
				{
					result = false;
				}
				bool flag2 = intPtr != IntPtr.Zero;
				if (flag2)
				{
					CoreFoundation.CFRelease(intPtr);
				}
				bool flag3 = intPtr2 != IntPtr.Zero;
				if (flag3)
				{
					CoreFoundation.CFRelease(intPtr2);
				}
			}
			catch 
			{
			}
			return result;
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "AMDeviceRemoveValue")]
		public static extern int AMDeviceRemoveValue_UInt32(IntPtr device, IntPtr domain, IntPtr cfsKey);

		public static bool AMDeviceSetValue(IntPtr device, string domain, string name, object value)
		{
			bool result = true;
			IntPtr intPtr = CoreFoundation.StringToCFString(domain);
			IntPtr intPtr2 = CoreFoundation.StringToCFString(name);
			IntPtr intPtr3 = CoreFoundation.CFTypeFromManagedType(value);
			bool flag = MobileDevice.AMDeviceSetValue_Int(device, intPtr, intPtr2, intPtr3) != 0;
			if (flag)
			{
				result = false;
			}
			bool flag2 = intPtr != IntPtr.Zero;
			if (flag2)
			{
				CoreFoundation.CFRelease(intPtr);
			}
			bool flag3 = intPtr2 != IntPtr.Zero;
			if (flag3)
			{
				CoreFoundation.CFRelease(intPtr2);
			}
			bool flag4 = intPtr3 != IntPtr.Zero;
			if (flag4)
			{
				CoreFoundation.CFRelease(intPtr3);
			}
			return result;
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "AMDeviceSetValue")]
		public static extern int AMDeviceSetValue_Int(IntPtr device, IntPtr domain, IntPtr cfsKey, IntPtr cfsValue);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceSetValue(IntPtr device, IntPtr mbz, IntPtr cfstringkey, IntPtr cfstringname);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceDeactivate(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceDisconnect(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceEnterRecovery(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceGetConnectionID(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceIsPaired(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceNotificationSubscribe(DeviceNotificationCallback callback, uint unused1, uint unused2, uint unused3, ref IntPtr am_device_notification_ptr);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AMDeviceNotificationUnsubscribe(IntPtr am_device_notification_ptr);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceRelease(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceStartService(IntPtr device, IntPtr service_name, ref int socket, IntPtr unknown);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void AMDeviceRetain(IntPtr device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceStartSession(IntPtr device);

		// Token: 0x0600007E RID: 126
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceStopSession(IntPtr device);

		// Token: 0x0600007F RID: 127
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceValidatePairing(IntPtr device);

		// Token: 0x06000080 RID: 128
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDevicePair(IntPtr device);

		// Token: 0x06000081 RID: 129
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AMDevicePairWithOptions(IntPtr device, IntPtr ptrOption);

		// Token: 0x06000082 RID: 130
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceUnpair(IntPtr device);

		// Token: 0x06000083 RID: 131
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError AMDListenForNotifications(int socket, DeviceEventSink callback, IntPtr userdata);

		// Token: 0x06000084 RID: 132
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr AMRecoveryModeDeviceCopyIMEI(byte[] device);

		// Token: 0x06000085 RID: 133
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeDeviceGetLocationID(byte[] device);

		// Token: 0x06000086 RID: 134
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeDeviceGetProductID(byte[] device);

		// Token: 0x06000087 RID: 135
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeDeviceGetProductType(byte[] device);

		// Token: 0x06000088 RID: 136
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeDeviceGetTypeID();

		// Token: 0x06000089 RID: 137
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeGetSoftwareBuildVersion();

		// Token: 0x0600008A RID: 138
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr AMRecoveryModeDeviceCopySerialNumber(byte[] device);

		// Token: 0x0600008B RID: 139
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr AMRecoveryModeDeviceCopyAuthlnstallPreflightOptions(byte[] byte_0, IntPtr intptr_0, IntPtr intptr_1);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public unsafe static extern int AMSEraseDevice(IntPtr uuid);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMSInitialize();

		public static int AMSEraseDevice(string deviceUUID)
		{
			return MobileDevice.AMSEraseDevice(CoreFoundation.StringToCFString(deviceUUID));
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeDeviceReboot(byte[] device);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRecoveryModeDeviceSetAutoBoot(byte[] device, byte paramByte);

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern string AMRestoreModeDeviceCopyIMEI(byte[] device);

		// Token: 0x0600008F RID: 143
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRestoreModeDeviceCreate(uint unknown0, int connection_id, uint unknown1);

		// Token: 0x06000090 RID: 144
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRestoreRegisterForDeviceNotifications(DeviceDFUNotificationCallback dfu_connect, DeviceRestoreNotificationCallback recovery_connect, DeviceDFUNotificationCallback dfu_disconnect, DeviceRestoreNotificationCallback recovery_disconnect, uint unknown0, ref IntPtr user_info);

		// Token: 0x06000091 RID: 145
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDeviceGetInterfaceType(IntPtr device);

		// Token: 0x06000092 RID: 146
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDServiceConnectionReceive(IntPtr socket, ref uint uint_0, int int_1);

		// Token: 0x06000093 RID: 147
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "AMDServiceConnectionReceive")]
		public static extern int AMDServiceConnectionReceive_1(IntPtr socket, IntPtr intptr_0, int int_1);

		// Token: 0x06000094 RID: 148
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMRestorePerformRecoveryModeRestore(byte[] device, IntPtr dicopts, DeviceInstallApplicationCallback callback, IntPtr user_info);

		// Token: 0x06000095 RID: 149
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr AMRestoreCreateDefaultOptions(IntPtr allocator);

		// Token: 0x06000096 RID: 150
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDServiceConnectionReceive(int inSocket, IntPtr buffer, int bufferlen);

		// Token: 0x06000097 RID: 151
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "AMDServiceConnectionReceive")]
		public static extern int AMDServiceConnectionReceive_UInt32(int inSocket, ref uint buffer, int bufferlen);

		// Token: 0x06000098 RID: 152
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int AMDServiceConnectionSend(int inSocket, IntPtr buffer, int bufferlen);

		// Token: 0x06000099 RID: 153
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "AMDServiceConnectionSend")]
		public static extern int AMDServiceConnectionSend_UInt32(int inSocket, ref uint buffer, int bufferlen);

		// Token: 0x0600009A RID: 154
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int USBMuxConnectByPort(int connectionID, uint iPhone_port_network_byte_order, ref int outSocket);

		// Token: 0x0600009B RID: 155
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint htonl(uint hostlong);

		// Token: 0x0600009C RID: 156
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint htons(uint hostshort);

		// Token: 0x0600009D RID: 157
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern uint ntohl(uint netlong);

		// Token: 0x0600009E RID: 158
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern int send(int inSocket, IntPtr buffer, int bufferlen, int flags);

		// Token: 0x0600009F RID: 159
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall, EntryPoint = "send")]
		public static extern int send_UInt32(int inSocket, ref uint buffer, int bufferlen, int flags);

		// Token: 0x060000A0 RID: 160
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall, SetLastError = true)]
		public static extern int recv(int inSocket, IntPtr buffer, int bufferlen, int flags);

		// Token: 0x060000A1 RID: 161
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall, EntryPoint = "recv")]
		public static extern int recv_UInt32(int inSocket, ref uint buffer, int bufferlen, int flags);

		// Token: 0x060000A2 RID: 162
		[DllImport("Ws2_32.dll", CallingConvention = CallingConvention.StdCall)]
		public static extern int closesocket(int inSocket);

		// Token: 0x060000A3 RID: 163 RVA: 0x00003D24 File Offset: 0x00001F24
		public static IntPtr ATCFMessageCreate(int sesssion, string strMessageType, Dictionary<object, object> dictParams)
		{
			IntPtr intPtr = CoreFoundation.StringToCFString(strMessageType);
			IntPtr intPtr2 = CoreFoundation.CFTypeFromManagedType(dictParams);
			IntPtr result = MobileDevice.ATCFMessageCreate_IntPtr(sesssion, intPtr, intPtr2);
			CoreFoundation.CFRelease(intPtr);
			CoreFoundation.CFRelease(intPtr2);
			return result;
		}

		// Token: 0x060000A4 RID: 164
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ATCFMessageCreate")]
		public static extern IntPtr ATCFMessageCreate_IntPtr(int sesssion, IntPtr hMessageType, IntPtr hParams);

		// Token: 0x060000A5 RID: 165 RVA: 0x00003D5C File Offset: 0x00001F5C
		public static IntPtr ATHostConnectionCreateWithLibrary(string strPrefsValue, string strUUID)
		{
			IntPtr intPtr = CoreFoundation.StringToCFString(strPrefsValue);
			IntPtr intPtr2 = CoreFoundation.StringToCFString(strUUID);
			IntPtr result = MobileDevice.ATHostConnectionCreateWithLibrary_IntPtr(intPtr, intPtr2, 0);
			CoreFoundation.CFRelease(intPtr2);
			CoreFoundation.CFRelease(intPtr);
			return result;
		}

		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ATHostConnectionCreateWithLibrary")]
		private static extern IntPtr ATHostConnectionCreateWithLibrary_IntPtr(IntPtr hPrefsValue, IntPtr hUUID, int unkonwn);

		// Token: 0x060000A7 RID: 167
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int ATHostConnectionGetCurrentSessionNumber(IntPtr hATHost);

		// Token: 0x060000A8 RID: 168
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern int ATHostConnectionGetGrappaSessionId(IntPtr hATHost);

		// Token: 0x060000A9 RID: 169
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ATHostConnectionReadMessage(IntPtr hATHost);

		// Token: 0x060000AA RID: 170
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ATHostConnectionRelease(IntPtr hATHost);

		// Token: 0x060000AB RID: 171 RVA: 0x00003D94 File Offset: 0x00001F94
		public static int ATHostConnectionSendAssetCompleted(IntPtr hATHost, string strPid, string strMediaType, string strFilePath)
		{
			IntPtr intPtr = CoreFoundation.CFStringMakeConstantString(strPid);
			IntPtr intPtr2 = CoreFoundation.CFStringMakeConstantString(strMediaType);
			IntPtr intPtr3 = CoreFoundation.CFStringMakeConstantString(strFilePath);
			IntPtr intPtr4 = MobileDevice.ATHostConnectionSendAssetCompleted_IntPtr(hATHost, intPtr, intPtr2, intPtr3);
			CoreFoundation.CFRelease(intPtr);
			CoreFoundation.CFRelease(intPtr2);
			CoreFoundation.CFRelease(intPtr3);
			return intPtr4.ToInt32();
		}

		// Token: 0x060000AC RID: 172
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ATHostConnectionSendAssetCompleted")]
		private static extern IntPtr ATHostConnectionSendAssetCompleted_IntPtr(IntPtr hATHost, IntPtr hPid, IntPtr hMediaType, IntPtr hFilePath);

		// Token: 0x060000AD RID: 173 RVA: 0x00003DE4 File Offset: 0x00001FE4
		public static int ATHostConnectionSendFileError(IntPtr hATHost, string strPid, string strMediaType, int intType)
		{
			IntPtr intPtr = CoreFoundation.CFStringMakeConstantString(strPid);
			IntPtr intPtr2 = CoreFoundation.CFStringMakeConstantString(strMediaType);
			IntPtr intPtr3 = (IntPtr)((int)MobileDevice.ATHostConnectionSendFileError_IntPtr(hATHost, intPtr, intPtr2, intType));
			CoreFoundation.CFRelease(intPtr);
			CoreFoundation.CFRelease(intPtr2);
			return intPtr3.ToInt32();
		}

		// Token: 0x060000AE RID: 174
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ATHostConnectionSendFileError")]
		private static extern kAMDError ATHostConnectionSendFileError_IntPtr(IntPtr hATHost, IntPtr hPid, IntPtr hMediaType, int intType);

		// Token: 0x060000AF RID: 175 RVA: 0x00003E28 File Offset: 0x00002028
		public static int ATHostConnectionSendFileProgress(IntPtr hATHost, string strPid, string strMediaType, double fileProgress, double totalProgress)
		{
			IntPtr intPtr = CoreFoundation.CFStringMakeConstantString(strPid);
			IntPtr intPtr2 = CoreFoundation.CFStringMakeConstantString(strMediaType);
			byte[] bytes = BitConverter.GetBytes(fileProgress);
			byte[] bytes2 = BitConverter.GetBytes(totalProgress);
			int proc1L = BitConverter.ToInt32(bytes, 0);
			int proc1H = BitConverter.ToInt32(bytes, 4);
			int proc2L = BitConverter.ToInt32(bytes2, 0);
			int proc2H = BitConverter.ToInt32(bytes2, 4);
			IntPtr intPtr3 = (IntPtr)((int)MobileDevice.ATHostConnectionSendFileProgress_IntPtr(hATHost, intPtr, intPtr2, proc1L, proc1H, proc2L, proc2H));
			CoreFoundation.CFRelease(intPtr);
			CoreFoundation.CFRelease(intPtr2);
			return intPtr3.ToInt32();
		}
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int AMDeviceSecureStartService(IntPtr device, IntPtr service_name, IntPtr unknown, ref int socketid);

		// Token: 0x0600011E RID: 286
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int AMDeviceSecureStartService(IntPtr device, IntPtr service_name, IntPtr unknown, ref long socketid);

		// Token: 0x0600011F RID: 287 RVA: 0x000069F0 File Offset: 0x00004BF0
		public static int AMDeviceSecureStartServiceEx(IntPtr device, string service_name, IntPtr unknown, ref long socketid)
		{
			if (Environment.Is64BitProcess)
			{
				return MobileDevice.AMDeviceSecureStartService(device, CoreFoundation.StringToCFString(service_name), unknown, ref socketid);
			}
			int num = -1;
			int result = MobileDevice.AMDeviceSecureStartService(device, CoreFoundation.StringToCFString(service_name), unknown, ref num);
			socketid = (long)num;
			return result;
		}

		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int AMDServiceConnectionGetSecureIOContext(int socketid);

		// Token: 0x0600012B RID: 299
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern long AMDServiceConnectionGetSecureIOContext(long socketid);

		// Token: 0x0600012C RID: 300 RVA: 0x00006AA1 File Offset: 0x00004CA1
		public static long AMDServiceConnectionGetSecureIOContextEx(long socketid)
		{
			if (!Environment.Is64BitProcess)
			{
				return (long)MobileDevice.AMDServiceConnectionGetSecureIOContext((int)socketid);
			}
			return MobileDevice.AMDServiceConnectionGetSecureIOContext(socketid);
		}
		[DllImport("iTunesMobileDevice.dll", CallingConvention = CallingConvention.Cdecl)]

		private static extern long AMDListenForNotifications(long conn, DeviceEventSink callback, IntPtr userdata);

		// Token: 0x0600012F RID: 303 RVA: 0x00006AB9 File Offset: 0x00004CB9
		public static long AMDListenForNotificationsEx(long conn, DeviceEventSink callback, IntPtr userdata)
		{
			if (!Environment.Is64BitProcess)
			{
				return (long)MobileDevice.AMDListenForNotifications((int)conn, callback, userdata);
			}
			return MobileDevice.AMDListenForNotifications(conn, callback, userdata);
		}
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ATHostConnectionSendFileProgress")]
		private static extern kAMDError ATHostConnectionSendFileProgress_IntPtr(IntPtr hATHost, IntPtr hPid, IntPtr hMediaType, int proc1L, int proc1H, int proc2L, int proc2H);

		// Token: 0x060000B1 RID: 177
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError ATHostConnectionSendHostInfo(IntPtr hATHost, IntPtr hDictInfo);

		// Token: 0x060000B2 RID: 178
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError ATHostConnectionSendMetadataSyncFinished(IntPtr hATHost, IntPtr hKeybag, IntPtr hMedia);

		// Token: 0x060000B3 RID: 179
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError ATHostConnectionSendPowerAssertion(IntPtr hATHost, IntPtr allocator);

		// Token: 0x060000B4 RID: 180
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern kAMDError ATHostConnectionSendSyncRequest(IntPtr hATHost, IntPtr hArrDataclasses, IntPtr hDictDataclassAnchors, IntPtr hDictHostInfo);

		// Token: 0x060000B5 RID: 181
		[DllImport("AirTrafficHost.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ATProcessLinkSendMessage(IntPtr hATHost, IntPtr hATCFMessage);

		// Token: 0x060000B6 RID: 182 RVA: 0x00003EAC File Offset: 0x000020AC
		public static IntPtr CFStringMakeConstantString(string s)
		{
			return CoreFoundation.StringToCFString(s);
		}
	}
}
