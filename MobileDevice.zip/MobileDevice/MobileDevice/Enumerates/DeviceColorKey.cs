﻿using System;

namespace MobileDevice.Enumerates
{
	// Token: 0x02000015 RID: 21
	public enum DeviceColorKey
	{
		// Token: 0x0400003F RID: 63
		Unknown = -1,
		// Token: 0x04000040 RID: 64
		Default,
		// Token: 0x04000041 RID: 65
		Black,
		// Token: 0x04000042 RID: 66
		Silver,
		// Token: 0x04000043 RID: 67
		Gold,
		// Token: 0x04000044 RID: 68
		Rose_Gold,
		// Token: 0x04000045 RID: 69
		Jet_Black
	}
}
