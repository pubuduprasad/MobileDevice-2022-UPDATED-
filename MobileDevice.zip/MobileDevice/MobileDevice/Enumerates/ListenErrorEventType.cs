﻿using System;

namespace MobileDevice.Enumerates
{
	// Token: 0x02000018 RID: 24
	public enum ListenErrorEventType
	{
		// Token: 0x040000ED RID: 237
		StartListen,
		// Token: 0x040000EE RID: 238
		Connect
	}
}
