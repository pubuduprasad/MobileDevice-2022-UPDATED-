﻿using System;

namespace MobileDevice.Enumerates
{
	// Token: 0x02000014 RID: 20
	public enum ConnectNotificationMessage
	{
		// Token: 0x0400003B RID: 59
		Connected = 1,
		// Token: 0x0400003C RID: 60
		Disconnected,
		// Token: 0x0400003D RID: 61
		Unknown
	}
}
