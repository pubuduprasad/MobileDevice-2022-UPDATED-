﻿using System;

namespace MobileDevice.Enumerates
{
	// Token: 0x02000017 RID: 23
	public enum kAMDError
	{
		// Token: 0x04000090 RID: 144
		kAMDAlreadyArchivedError = -402653094,
		// Token: 0x04000091 RID: 145
		kAMDApplicationAlreadyInstalledError = -402653130,
		// Token: 0x04000092 RID: 146
		kAMDApplicationMoveFailedError,
		// Token: 0x04000093 RID: 147
		kAMDApplicationSandboxFailedError = -402653127,
		// Token: 0x04000094 RID: 148
		kAMDApplicationSINFCaptureFailedError = -402653128,
		// Token: 0x04000095 RID: 149
		kAMDApplicationVerificationFailedError = -402653126,
		// Token: 0x04000096 RID: 150
		kAMDArchiveDestructionFailedError,
		// Token: 0x04000097 RID: 151
		kAMDBadHeaderError = -402653182,
		// Token: 0x04000098 RID: 152
		kAMDBundleVerificationFailedError = -402653124,
		// Token: 0x04000099 RID: 153
		kAMDBusyError = -402653167,
		// Token: 0x0400009A RID: 154
		kAMDCarrierBundleCopyFailedError = -402653123,
		// Token: 0x0400009B RID: 155
		kAMDCarrierBundleDirectoryCreationFailedError,
		// Token: 0x0400009C RID: 156
		kAMDCarrierBundleMissingSupportedSIMsError,
		// Token: 0x0400009D RID: 157
		kAMDCheckinTimeoutError = -402653148,
		// Token: 0x0400009E RID: 158
		kAMDCommCenterNotificationFailedError = -402653120,
		// Token: 0x0400009F RID: 159
		kAMDContainerCreationFailedError,
		// Token: 0x040000A0 RID: 160
		kAMDContainerP0wnFailedError,
		// Token: 0x040000A1 RID: 161
		kAMDContainerRemovalFailedError,
		// Token: 0x040000A2 RID: 162
		kAMDCryptoError = -402653166,
		// Token: 0x040000A3 RID: 163
		kAMDDigestFailedError = -402653135,
		// Token: 0x040000A4 RID: 164
		kAMDEmbeddedProfileInstallFailedError = -402653116,
		// Token: 0x040000A5 RID: 165
		kAMDEOFError = -402653170,
		// Token: 0x040000A6 RID: 166
		kAMDErrorError = -402653115,
		// Token: 0x040000A7 RID: 167
		kAMDExecutableTwiddleFailedError,
		// Token: 0x040000A8 RID: 168
		kAMDExistenceCheckFailedError,
		// Token: 0x040000A9 RID: 169
		kAMDFileExistsError = -402653168,
		// Token: 0x040000AA RID: 170
		kAMDGetProhibitedError = -402653162,
		// Token: 0x040000AB RID: 171
		kAMDImmutableValueError = -402653159,
		// Token: 0x040000AC RID: 172
		kAMDInstallMapUpdateFailedError = -402653112,
		// Token: 0x040000AD RID: 173
		kAMDInvalidActivationRecordError = -402653146,
		// Token: 0x040000AE RID: 174
		kAMDInvalidArgumentError = -402653177,
		// Token: 0x040000AF RID: 175
		kAMDInvalidCheckinError = -402653149,
		// Token: 0x040000B0 RID: 176
		kAMDInvalidDiskImageError = -402653133,
		// Token: 0x040000B1 RID: 177
		kAMDInvalidHostIDError = -402653156,
		// Token: 0x040000B2 RID: 178
		kAMDInvalidResponseError = -402653165,
		// Token: 0x040000B3 RID: 179
		kAMDInvalidServiceError = -402653150,
		// Token: 0x040000B4 RID: 180
		kAMDInvalidSessionIDError = -402653152,
		// Token: 0x040000B5 RID: 181
		kAMDIsDirectoryError = -402653175,
		// Token: 0x040000B6 RID: 182
		kAMDiTunesArtworkCaptureFailedError = -402653096,
		// Token: 0x040000B7 RID: 183
		kAMDiTunesMetadataCaptureFailedError,
		// Token: 0x040000B8 RID: 184
		kAMDManifestCaptureFailedError = -402653111,
		// Token: 0x040000B9 RID: 185
		kAMDMapGenerationFailedError,
		// Token: 0x040000BA RID: 186
		kAMDMissingActivationRecordError = -402653145,
		// Token: 0x040000BB RID: 187
		kAMDMissingBundleExecutableError = -402653109,
		// Token: 0x040000BC RID: 188
		kAMDMissingBundleIdentifierError,
		// Token: 0x040000BD RID: 189
		kAMDMissingBundlePathError,
		// Token: 0x040000BE RID: 190
		kAMDMissingContainerError,
		// Token: 0x040000BF RID: 191
		kAMDMissingDigestError = -402653132,
		// Token: 0x040000C0 RID: 192
		kAMDMissingHostIDError = -402653157,
		// Token: 0x040000C1 RID: 193
		kAMDMissingImageTypeError = -402653136,
		// Token: 0x040000C2 RID: 194
		kAMDMissingKeyError = -402653164,
		// Token: 0x040000C3 RID: 195
		kAMDMissingOptionsError = -402653137,
		// Token: 0x040000C4 RID: 196
		kAMDMissingPairRecordError = -402653147,
		// Token: 0x040000C5 RID: 197
		kAMDMissingServiceError = -402653151,
		// Token: 0x040000C6 RID: 198
		kAMDMissingSessionIDError = -402653153,
		// Token: 0x040000C7 RID: 199
		kAMDMissingValueError = -402653163,
		// Token: 0x040000C8 RID: 200
		kAMDMuxError = -402653131,
		// Token: 0x040000C9 RID: 201
		kAMDNoResourcesError = -402653181,
		// Token: 0x040000CA RID: 202
		kAMDNotConnectedError = -402653173,
		// Token: 0x040000CB RID: 203
		kAMDNotFoundError = -402653176,
		// Token: 0x040000CC RID: 204
		kAMDNotificationFailedError = -402653105,
		// Token: 0x040000CD RID: 205
		kAMDOverrunError = -402653171,
		// Token: 0x040000CE RID: 206
		kAMDPackageExtractionFailedError = -402653104,
		// Token: 0x040000CF RID: 207
		kAMDPackageInspectionFailedError,
		// Token: 0x040000D0 RID: 208
		kAMDPackageMoveFailedError,
		// Token: 0x040000D1 RID: 209
		kAMDPasswordProtectedError = -402653158,
		// Token: 0x040000D2 RID: 210
		kAMDPathConversionFailedError = -402653101,
		// Token: 0x040000D3 RID: 211
		kAMDPermissionError = -402653174,
		// Token: 0x040000D4 RID: 212
		kAMDProvisioningProfileNotValid = -402653140,
		// Token: 0x040000D5 RID: 213
		kAMDReadError = -402653180,
		// Token: 0x040000D6 RID: 214
		kAMDReceiveMessageError = -402653138,
		// Token: 0x040000D7 RID: 215
		kAMDRemoveProhibitedError = -402653160,
		// Token: 0x040000D8 RID: 216
		kAMDRestoreContainerFailedError = -402653100,
		// Token: 0x040000D9 RID: 217
		kAMDSeatbeltProfileRemovalFailedError,
		// Token: 0x040000DA RID: 218
		kAMDSendMessageError = -402653139,
		// Token: 0x040000DB RID: 219
		kAMDSessionActiveError = -402653155,
		// Token: 0x040000DC RID: 220
		kAMDSessionInactiveError,
		// Token: 0x040000DD RID: 221
		kAMDSetProhibitedError = -402653161,
		// Token: 0x040000DE RID: 222
		kAMDStageCreationFailedError = -402653098,
		// Token: 0x040000DF RID: 223
		kAMDStartServiceError = -402653134,
		// Token: 0x040000E0 RID: 224
		kAMDSuccess = 0,
		// Token: 0x040000E1 RID: 225
		kAMDSUFirmwareError = -402653141,
		// Token: 0x040000E2 RID: 226
		kAMDSUPatchError = -402653142,
		// Token: 0x040000E3 RID: 227
		kAMDSUVerificationError = -402653143,
		// Token: 0x040000E4 RID: 228
		kAMDSymlinkFailedError = -402653097,
		// Token: 0x040000E5 RID: 229
		kAMDTimeOutError = -402653172,
		// Token: 0x040000E6 RID: 230
		kAMDTrustComputerError = -402653034,
		// Token: 0x040000E7 RID: 231
		kAMDUndefinedError = -402653183,
		// Token: 0x040000E8 RID: 232
		kAMDUnknownPacketError = -402653178,
		// Token: 0x040000E9 RID: 233
		kAMDUnsupportedError = -402653169,
		// Token: 0x040000EA RID: 234
		kAMDWriteError = -402653179,
		// Token: 0x040000EB RID: 235
		kAMDWrongDroidError = -402653144
	}
}
