﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;
using MobileDevice.CoreFundation;
using MobileDevice.Enumerates;
using MobileDevice.Unitiy;

namespace MobileDevice
{

	public class iOSDevice   
	{
		private bool isConnected = false;
		private bool isSessionOpen = false;
		private string activationstate = string.Empty;
		private string basebandbootloaderversion = string.Empty;
		private string basebandserialNumber = string.Empty;
		private string basebandversion = string.Empty;
		private string bluetoothaddress = string.Empty;
		private string buildversion = string.Empty;
		private string cpuarchitecture = string.Empty;
		private string devicecolor = string.Empty;
		private string basebandstatus = string.Empty;
		private string deviceclass = string.Empty;
		private string mobileequipmentidentifier = string.Empty;
		private string chipid = string.Empty;
		private string devicename = string.Empty;
		private string firmwareversion = string.Empty;
		private string hardwaremodel = string.Empty;
		private string modelnumber = string.Empty;
		private string phonenumber = string.Empty;
		private string producttype = string.Empty;
		private string integratedcircuitcardidentity = string.Empty;
		private string internationalmobileequipmentidentity = string.Empty;
		private string serialnumber = string.Empty;
		private string simstatus = string.Empty;
		private string simtraystatus = string.Empty;
		private string uniquedeviceid = string.Empty;
		private string uniquechipid = string.Empty;    
		private string wifiaddress = string.Empty;
		private string productversion = string.Empty;
		private string basebandchipid = string.Empty;   
		public IntPtr DevicePtr;
		/*
            @NivalXer
			@WeiPhone技术组
			MobileDevice.dll
		
			added: UniqueChipID
			added: MobileEquipmentIdentifier
			added: BasebandChipId
			added: DeviceClass
			added: ChipID
			added: SIMTrayStatus
			added: BasebandStatus  
			added: EraseDevice
			added: IsOpenFindMyDevice
			
			updated by zecode.lk (@pubuduprasad) on february 13, 2022
			copyright © 2022 mobiledevice all rights reserved.
		 */
		public bool IsConnected
		{
			get
			{
				return this.isConnected;
			}
		}
		public iOSDevice(IntPtr devicePtr)
		{
			this.DevicePtr = devicePtr;
			this.ConnectAndInitService();
		}
		public kAMDError Connect()
		{
			kAMDError kAMDError = kAMDError.kAMDSuccess;
			try
			{
				if (!this.isConnected)
				{
					kAMDError = (kAMDError)MobileDevice.AMDeviceConnect(this.DevicePtr);
					if (kAMDError == kAMDError.kAMDSuccess)
					{
						this.isConnected = true;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
			}
			return kAMDError;
		}
		public kAMDError Disconnect()
		{
			kAMDError result = kAMDError.kAMDSuccess;
			this.isConnected = false;
			try
			{
				result = (kAMDError)MobileDevice.AMDeviceDisconnect(this.DevicePtr);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
			}
			return result;
		}
		private bool ConnectAndInitService()
		{
			bool result = false;
			try
			{
				if (this.Connect() > kAMDError.kAMDSuccess)
				{
					return false;
				}
				if (MobileDevice.AMDeviceValidatePairing(this.DevicePtr) != 0)
				{
					kAMDError kAMDError = (kAMDError)MobileDevice.AMDevicePair(this.DevicePtr);
					if (kAMDError > kAMDError.kAMDSuccess)
					{
						this.Disconnect();
						return false;
					}
				}
				this.isSessionOpen = false;
				if (this.StartSession(false) == kAMDError.kAMDSuccess)
				{
					this.isConnected = true;
					this.StopSession();
					result = true;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
			}
			return result;
		}
		public kAMDError StartSession(bool isRretry = false)
		{
			kAMDError kAMDError = kAMDError.kAMDSuccess;
			try
			{
				if (!this.isSessionOpen)
				{
					kAMDError = (kAMDError)MobileDevice.AMDeviceStartSession(this.DevicePtr);
					if (kAMDError != kAMDError.kAMDInvalidHostIDError)
					{
						bool IskAMDError = kAMDError > kAMDError.kAMDSuccess;
						if (!IskAMDError)
						{
							this.isSessionOpen = true;
							return kAMDError;
						}
						if (!isRretry)
						{
							this.Disconnect();
							this.Connect();
							return this.StartSession(true);
						}
						return kAMDError;
					}
					else
					{
						if (MobileDevice.AMDeviceUnpair(this.DevicePtr) == 0 && MobileDevice.AMDevicePair(this.DevicePtr) == 0)
						{
							kAMDError = (kAMDError)MobileDevice.AMDeviceStartSession(this.DevicePtr);
							if (kAMDError > kAMDError.kAMDSuccess)
							{
								return kAMDError;
							}
							this.isSessionOpen = true;
							return kAMDError;
						}
					}
				}
				return kAMDError;
			}
			catch
			{
				kAMDError = kAMDError.kAMDUndefinedError;
			}
			return kAMDError;
		}
		private kAMDError StopSession()
		{
			this.isSessionOpen = false;
			kAMDError result;
			try
			{
				result = (kAMDError)MobileDevice.AMDeviceStopSession(this.DevicePtr);
			}
			catch
			{
				result = kAMDError.kAMDUndefinedError;
			}
			return result;
		}
		private bool StartSocketService(string serviceName, ref int serviceSocket)
		{
			bool result;
			if (serviceSocket > 0)
			{
				result = true;
			}
			else
			{
				if (!this.isConnected)
				{
					if (this.Connect() > kAMDError.kAMDSuccess)
					{
						Console.WriteLine("StartService()执行Connect()失败");
						return false;
					}
				}
				bool text = false;
				if (!this.isSessionOpen)
				{
					kAMDError kAMDError = this.StartSession(false);
					bool IskAMDError = kAMDError == kAMDError.kAMDSuccess;
					if (!IskAMDError)
					{
						return false;
					}
					text = true;  
				}
				bool Services = false;  
				IntPtr zero = IntPtr.Zero;
				if (MobileDevice.AMDeviceSecureStartService(this.DevicePtr, CoreFoundation.StringToCFString(serviceName), IntPtr.Zero, ref zero) == 0)
				{
					serviceSocket = MobileDevice.AMDServiceConnectionGetSocket(zero);
					Services = true;
				}
				else
				{
					if (MobileDevice.AMDeviceStartService(this.DevicePtr, CoreFoundation.StringToCFString(serviceName), ref serviceSocket, IntPtr.Zero) == 0)
					{
						Services = true;
					}
				}
				if (text)
				{
					this.StopSession();
				}
				result = Services;
			}
			return result;
		}
		private bool StopSocketService(ref int socket)
		{
			kAMDError kAMDError = kAMDError.kAMDSuccess;
			if (socket > 0)
			{
				try
				{
					kAMDError = (kAMDError)MobileDevice.closesocket(socket);
				}
				catch 
				{
					return false;
				}
			}
			socket = 0;
			return kAMDError > kAMDError.kAMDSuccess;
		}
		public bool SendMessageToSocket(int sock, IntPtr message)
		{
			bool result;
			if (sock < 1 || message == IntPtr.Zero)
			{
				result = false;
			}
			else
			{
				bool text = false;
				IntPtr intPtr = CoreFoundation.CFWriteStreamCreateWithAllocatedBuffers(IntPtr.Zero, IntPtr.Zero);
				if (intPtr != IntPtr.Zero)
				{
					if (!CoreFoundation.CFWriteStreamOpen(intPtr))
					{
						return false;
					}
					IntPtr zero = IntPtr.Zero;
					if (CoreFoundation.CFPropertyListWriteToStream(message, intPtr, CFPropertyListFormat.kCFPropertyListBinaryFormat_v1_0, ref zero) > 0)
					{
						IntPtr kCFStreamPropertyDataWritten = CoreFoundation.kCFStreamPropertyDataWritten;
						IntPtr intPtr2 = CoreFoundation.CFWriteStreamCopyProperty(intPtr, kCFStreamPropertyDataWritten);
						IntPtr buffer = CoreFoundation.CFDataGetBytePtr(intPtr2);
						int num = CoreFoundation.CFDataGetLength(intPtr2);
						uint num2 = MobileDevice.htonl((uint)num);
						int num3 = Marshal.SizeOf(num2);
						if (MobileDevice.send_UInt32(sock, ref num2, num3, 0) != num3)
						{
							Console.WriteLine("could not send message size");
						}
						else
						{
							if (MobileDevice.send(sock, buffer, num, 0) != num)
							{
								Console.WriteLine("Could not send message.");
							}
							else
							{
								text = true;
							}
						}
						CoreFoundation.CFRelease(intPtr2);
					}
					CoreFoundation.CFWriteStreamClose(intPtr);
				}
				result = text;
			}
			return result;
		}
		public bool SendMessageToSocket(int sock, object dict)
		{
			IntPtr message = CoreFoundation.CFTypeFromManagedType(RuntimeHelpers.GetObjectValue(dict));
			return this.SendMessageToSocket(sock, message);
		}
		public object ReceiveMessageFromSocket(int sock)
		{
			object result;
			if (sock < 0)
			{
				result = null;
			}
			else
			{
				uint netlong = 0U;
				uint num = 0U;
				IntPtr intPtr = IntPtr.Zero;
				int num2;
				do
				{
					num2 = MobileDevice.recv_UInt32(sock, ref netlong, 4, 0);
				}
				while (num2 < 0);
				if (num2 != 4)
				{
					result = null;
				}
				else
				{
					uint num3 = MobileDevice.ntohl(netlong);
					if (num3 <= 0U)
					{
						Console.WriteLine("receive size error, dataSize:" + num3);
						result = null;
					}
					else
					{
						intPtr = Marshal.AllocCoTaskMem((int)num3);
						if (intPtr == IntPtr.Zero)
						{
							Console.WriteLine("Could not allocate message buffer.");
							result = null;
						}
						else
						{
							IntPtr buffer = intPtr;
							while (num < num3)
							{
								num2 = MobileDevice.recv(sock, buffer, (int)(num3 - num), 0);
								if (num2 <= -1)
								{
									Console.WriteLine("Could not receive secure message: " + num2);
									num = num3 + 1U;
								}
								else
								{
									if (num2 == 0)
									{
										Console.WriteLine("receive size is zero. ");
										break;
									}
									buffer = new IntPtr(buffer.ToInt64() + (long)num2);
									num += (uint)num2;
								}
							}
							IntPtr intPtr2 = IntPtr.Zero;
							IntPtr intPtr3 = IntPtr.Zero;
							if (num == num3)
							{
								intPtr2 = CoreFoundation.CFDataCreate(CoreFoundation.kCFAllocatorDefault, intPtr, (int)num3);
								if (intPtr2 == IntPtr.Zero)
								{
									Console.WriteLine("Could not create CFData for message");
								}
								else
								{
									IntPtr zero = IntPtr.Zero;
									intPtr3 = CoreFoundation.CFPropertyListCreateFromXMLData(CoreFoundation.kCFAllocatorDefault, intPtr2, CFPropertyListMutabilityOptions.kCFPropertyListImmutable, ref zero);
									if (intPtr3 == IntPtr.Zero)
									{
										Console.WriteLine("Could not convert raw xml into a dictionary: " + Convert.ToString(CoreFoundation.ManagedTypeFromCFType(ref zero)));
										return null;
									}
								}
							}
							if (intPtr2 != IntPtr.Zero)
							{
								try
								{
									CoreFoundation.CFRelease(intPtr2);
								}
								catch
								{
								}
							}
							if (intPtr != IntPtr.Zero)
							{
								Marshal.FreeCoTaskMem(intPtr);
							}
							object obj = CoreFoundation.ManagedTypeFromCFType(ref intPtr3);
							if (intPtr3 != IntPtr.Zero)
							{
								CoreFoundation.CFRelease(intPtr3);
							}
							result = obj;
						}
					}
				}
			}
			return result;
		}
		public object GetDeviceValue(DeviceInfoKey key)
		{
			return this.GetDeviceValue(null, key);
		}
		public object GetDeviceValue(string domain, DeviceInfoKey key)
		{
			return this.GetDeviceValue(domain, key.ToString());
		}
		public object GetDeviceValue(string domain, string key)
		{
			object result = null;
			try
			{
				bool connection = false;
				bool text = false;
				if (!this.isConnected)
				{
					if (this.Connect() > kAMDError.kAMDSuccess)
					{
						return null;
					}
					connection = true;
				}
				if (!this.isSessionOpen)
				{
					if (this.StartSession(false) == kAMDError.kAMDSuccess)
					{
						text = true;
					}
					else
					{
						if (connection)
						{
							this.Disconnect();
						}
					}
				}
				result = MobileDevice.AMDeviceCopyValue(this.DevicePtr, domain, key);
				if (text)
				{
					this.StopSession();
				}
				if (connection)
				{
					this.Disconnect();
				}
			}
			catch
			{
			}
			return result;
		}
		public int GetBatteryCurrentCapacity()
		{
			try
			{
				string deviceValue = Convert.ToString(this.GetDeviceValue("com.apple.mobile.battery", DeviceInfoKey.BatteryCurrentCapacity)) + string.Empty;
				if (deviceValue.Length > 0)
				{
					return SafeConvert.ToInt32(deviceValue);
				}
			}
			catch 
			{			
			}
			return -1;
		}
		public bool GetBatteryIsCharging()
		{
			try
			{
				object deviceValue = this.GetDeviceValue("com.apple.mobile.battery", DeviceInfoKey.BatteryIsCharging);
				if (deviceValue != null && deviceValue is bool)
				{
					return Convert.ToBoolean(deviceValue);
				}
			}
			catch
			{
			}
			return false;
		}
		public Dictionary<object, object> GetBatteryInfoFormDiagnostics()
		{
			Dictionary<object, object> result;
			try
			{
				object diagnosticsInfo = this.GetDiagnosticsInfo();
				if (diagnosticsInfo == null)
				{
					result = null;
				}
				else
				{
					Dictionary<object, object> dictionary = diagnosticsInfo as Dictionary<object, object>;
					if (dictionary["Status"].ToString() != "Success")
					{
						result = null;
					}
					else
					{
						Dictionary<object, object> dictionary_ = dictionary["Diagnostics"] as Dictionary<object, object>;
						if (dictionary_ == null)
						{
							result = null;
						}
						else
						{
							result = (dictionary_["GasGauge"] as Dictionary<object, object>);
						}
					}
				}
			}
			catch  
			{
				result = null;
			}
			return result;
		}
		public object GetDiagnosticsInfo()
		{
			int sock = 0;
			object result;
			if (!this.StartSocketService("com.apple.mobile.diagnostics_relay", ref sock))
			{
				result = null;
			}
			else
			{
				Dictionary<object, object> dictionary = new Dictionary<object, object>();
				dictionary.Add("Request", "All");
				bool flag3 = this.SendMessageToSocket(sock, dictionary);
				if (flag3)
				{
					object obj = this.ReceiveMessageFromSocket(sock);
					result = obj;
				}
				else
				{
			
					result = null;
				}
			}
			return result;
		}
		public bool IsOpenFindMyDevice()
		{
			bool result = false;
			if (this.AMDeviceConnectOrCheck() == 0)
			{
				string text = (string)MobileDevice.AMDeviceCopyValue(this.DevicePtr, "com.apple.fmip", "IsAssociated");
				if (!string.IsNullOrEmpty(text))
				{
					bool info = false;
					char[] array = text.ToCharArray();
					if (array != null && array.Count<char>() > 0)
					{
						char[] array_ = array;
						for (int i = 0; i < array_.Length; i++)
						{
							info = char.IsNumber(array_[i]);
						}
					}
					if (info)
					{
						result = Convert.ToBoolean(Convert.ToInt32(text));
					}
				}
			}
			return result;
		}
		public int AMDeviceConnectOrCheck()
		{
			int num = 0;
			if (!this.isConnected)
			{
				num = MobileDevice.AMDeviceConnect(this.DevicePtr);
				if (num == 0)
				{
					this.isConnected = true;
				}
			}
			return num;
		}
		public string EraseDevice()
		{
			string result;
			if (this.ActivationState != "Unactivated")
            {
                try
                {
					if (!string.IsNullOrEmpty(iTunesHelper.GetMobileBackup()))
					{
						Process[] processes = Process.GetProcessesByName("AppleMobileBackup");
						if (processes != null && processes.Length != 0)
						{
							Process[] array = processes;
							for (int i = 0; i < array.Length; i++)
							{
								array[i].Kill();
							}
						}
						Thread.Sleep(300);
						using (Process process = new Process())
						{
							process.StartInfo.FileName = iTunesHelper.GetMobileBackup();
							process.StartInfo.Arguments = string.Format("-E --target {0}", this.UniqueDeviceID);
							process.StartInfo.UseShellExecute = false;
							process.StartInfo.RedirectStandardOutput = true;
							process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
							process.StartInfo.CreateNoWindow = true;
							process.Start();
							process.StandardOutput.ReadToEnd();
							process.WaitForExit();
						}
						result = "200";
                    }
                    else
                    {
						MobileDevice.AMSInitialize();
						MobileDevice.AMSEraseDevice(this.UniqueDeviceID);
						result = "200";
					}
					result = "-15";
				}
				catch
				{
					MobileDevice.AMSInitialize();
					MobileDevice.AMSEraseDevice(this.UniqueDeviceID);
					result = "200";
				}			
			}
			else
			{
				result = "-22";
			}
			return result;
		}
		public string ActivationState
		{
			get
			{
				if (this.activationstate.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.ActivationState);
					if (deviceValue != null)
					{
						this.activationstate = deviceValue.ToString();
					}
				}
				return this.activationstate;
			}
		}
		public string BasebandBootloaderVersion
		{
			get
			{
				if (this.basebandbootloaderversion.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BasebandBootloaderVersion);
					if (deviceValue != null)
					{
						this.basebandbootloaderversion = deviceValue.ToString();
					}
				}
				return this.basebandbootloaderversion;
			}
		}
		public string BasebandSerialNumber
		{
			get
			{
				if (this.basebandserialNumber.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BasebandSerialNumber);
					if (deviceValue != null)
					{
						this.basebandserialNumber = deviceValue.ToString();
					}
				}
				return this.basebandserialNumber;
			}
		}
		public string BasebandVersion
		{
			get
			{
				if (this.basebandversion.Length == 0)  
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BasebandVersion);
					if (deviceValue != null)
					{
						this.basebandversion = deviceValue.ToString();
					}
				}
				return this.basebandversion;
			}
		}
		public string BasebandChipId
		{
			get
			{
				if (this.basebandchipid.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BasebandChipId);
					if (deviceValue != null)
					{
						this.basebandchipid = deviceValue.ToString();
					}
				}
				return this.basebandchipid;
			}
		}
		public string BluetoothAddress
		{
			get
			{
				if (this.bluetoothaddress.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BluetoothAddress);
					if (deviceValue != null)
					{
						this.bluetoothaddress = deviceValue.ToString();
					}
				}
				return this.bluetoothaddress;
			}
		}
		public string BuildVersion
		{
			get
			{
				if (this.buildversion.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BuildVersion);
					if (deviceValue != null)
					{
						this.buildversion = deviceValue.ToString();
					}
				}
				return this.buildversion;
			}
		}
		public string ChipID  
		{
			get
			{
				if (this.chipid.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(null, "ChipID").ToString();
					if (deviceValue != null)
					{
						this.chipid = deviceValue.ToString();
					}
				}
				return this.chipid;
			}
		}
		public string CPUArchitecture
		{
			get
			{
				if (this.cpuarchitecture.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.CPUArchitecture);
					if (deviceValue != null)
					{
						this.cpuarchitecture = deviceValue.ToString();
					}
				}
				return this.cpuarchitecture;
			}
		}
		public string DeviceColor
		{
			get
			{
				if (string.IsNullOrWhiteSpace(devicecolor))
				{
					var deviceColorValue = GetDeviceValue(DeviceInfoKey.DeviceColor);
					if (deviceColorValue != null)
					{
						devicecolor = deviceColorValue.ToString();
					}
				}

				return devicecolor;
			}
		}
		public string DeviceName
		{
			get
			{
				if (this.devicename.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.DeviceName);
					if (deviceValue != null)
					{
						this.devicename = deviceValue.ToString();
					}
				}
				return this.devicename;
			}
		}
		public string FirmwareVersion
		{
			get
			{
				if (this.firmwareversion.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.FirmwareVersion);
					if (deviceValue != null)
					{
						this.firmwareversion = deviceValue.ToString();
					}
				}
				return this.firmwareversion;
			}
		}
		public string SIMTrayStatus
		{
			get
			{
				if (this.simtraystatus.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.SIMTrayStatus);
					if (deviceValue != null)
					{
						this.simtraystatus = deviceValue.ToString();
					}
				}
				return this.simtraystatus;
			}
		}
		public string HardwareModel
		{
			get
			{
				if (this.hardwaremodel.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.HardwareModel);
					if (deviceValue != null)
					{
						this.hardwaremodel = deviceValue.ToString();
					}
				}
				return this.hardwaremodel;
			}
		}
		public string ModelNumber
		{
			get
			{
				if (this.modelnumber.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.ModelNumber);
					if (deviceValue != null)
					{
						this.modelnumber = deviceValue.ToString();
					}
				}
				return this.modelnumber;
			}
		}
		public string PhoneNumber
		{
			get
			{
				if (this.phonenumber.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.PhoneNumber);
					if (deviceValue != null)
					{
						this.phonenumber = deviceValue.ToString();
					}
				}
				return this.phonenumber;
			}
		}
		public string ProductType
		{
			get
			{
				if (this.producttype.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.ProductType);
					if (deviceValue != null)
					{
						this.producttype = deviceValue.ToString();
					}
				}
				return this.producttype;
			}
		}
		public string IntegratedCircuitCardIdentity
		{
			get
			{
				if (this.integratedcircuitcardidentity.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.IntegratedCircuitCardIdentity);
					if (deviceValue != null)
					{
						this.integratedcircuitcardidentity = deviceValue.ToString();
					}
				}
				return this.integratedcircuitcardidentity;   
			}
		}
		public string InternationalMobileEquipmentIdentity
		{
			get
			{
				if (this.internationalmobileequipmentidentity.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.InternationalMobileEquipmentIdentity);
					if (deviceValue != null)
					{
						this.internationalmobileequipmentidentity = deviceValue.ToString();
					}
				}
				return this.internationalmobileequipmentidentity;
			}
		}
		public string MobileEquipmentIdentifier
		{
			get
			{
				if (mobileequipmentidentifier.Length == 0)
				{
					object deviceValue = GetDeviceValue(DeviceInfoKey.MobileEquipmentIdentifier);
					if (deviceValue != null)
					{
						mobileequipmentidentifier = deviceValue.ToString();
					}
				}
				return mobileequipmentidentifier;
			}
			set
			{
				mobileequipmentidentifier = MobileEquipmentIdentifier;
			}
		}
		public string BasebandStatus
		{
			get
			{
				if (this.basebandstatus.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.BasebandStatus);
					if (deviceValue != null)
					{
						this.basebandstatus = deviceValue.ToString();
					}
				}
				return this.basebandstatus;
			}
		}
		public string DeviceClass
		{
			get
			{
				if (this.deviceclass.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.DeviceClass);
					if (deviceValue != null)
					{
						this.deviceclass = deviceValue.ToString();
					}
				}
				return this.deviceclass;
			}
		}
		public string SerialNumber
		{
			get
			{
				if (this.serialnumber.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.SerialNumber);
					if (deviceValue != null)
					{
						this.serialnumber = deviceValue.ToString();
					}
				}
				return this.serialnumber;
			}
		}
		public string SIMStatus
		{
			get
			{
				if (this.simstatus.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.SIMStatus);
					if (deviceValue != null)
					{
						this.simstatus = deviceValue.ToString();
					}
				}
				return this.simstatus;
			}
		}
		public string UniqueDeviceID  
		{
			get
			{
				if (this.uniquedeviceid.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.UniqueDeviceID);
					if (deviceValue != null)
					{
						this.uniquedeviceid = deviceValue.ToString();
					}
				}
				return this.uniquedeviceid;
			}
		}
		public string UniqueChipID
		{
			get
			{
				if (this.uniquechipid.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.UniqueChipID);
					if (deviceValue != null)
					{
						this.uniquechipid = deviceValue.ToString();
					}
				}
				return this.uniquechipid;
			}
		}
		public string WiFiAddress
		{
			get
			{
				if (this.wifiaddress.Length == 0)
				{
					object deviceValue = this.GetDeviceValue(DeviceInfoKey.WiFiAddress);
					if (deviceValue != null)
					{
						this.wifiaddress = deviceValue.ToString();
					}
				}
				return this.wifiaddress;
			}
		}
		public string ProductVersion
		{
			get
			{
				if (string.IsNullOrEmpty(this.productversion))
				{
					this.productversion = Convert.ToString(this.GetDeviceValue(DeviceInfoKey.ProductVersion)) + string.Empty;
				}
				return this.productversion;
			}
		}
		public string Identifier
		{
			get
			{
				string result = string.Empty;
				IntPtr intPtr = IntPtr.Zero;
				try
				{
					intPtr = MobileDevice.AMDeviceCopyDeviceIdentifier(this.DevicePtr);
				}
				catch (Exception ex)
				{
					Console.WriteLine(ex.ToString());
				}
				finally
				{
					if (intPtr != IntPtr.Zero)
					{
						result = Convert.ToString(CoreFoundation.ManagedTypeFromCFType(ref intPtr));
						CoreFoundation.CFRelease(intPtr);
					}
				}
				return result;
			}
		}
	}
}
