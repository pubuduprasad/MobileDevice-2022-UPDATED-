﻿using System;

namespace MobileDevice
{
	// Token: 0x02000003 RID: 3
	public class iOSRecoveryDevice
	{
		// Token: 0x0400000B RID: 11
		public byte[] DevicePtr;
	}
}
