﻿using System;
using MobileDevice.Enumerates;

namespace MobileDevice.Event
{
	// Token: 0x0200000F RID: 15
	public class DeviceCommonConnectEventArgs : EventArgs
	{
		// Token: 0x060000F6 RID: 246 RVA: 0x00004A0F File Offset: 0x00002C0F
		internal DeviceCommonConnectEventArgs(iOSDevice device, ConnectNotificationMessage message)
		{
			this.device = device;
			this.message = message;
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000F7 RID: 247 RVA: 0x00004A28 File Offset: 0x00002C28
		public iOSDevice Device
		{
			get
			{
				return this.device;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x00004A40 File Offset: 0x00002C40
		public ConnectNotificationMessage Message
		{
			get
			{
				return this.message;
			}
		}

		// Token: 0x04000034 RID: 52
		private readonly iOSDevice device;

		// Token: 0x04000035 RID: 53
		private readonly ConnectNotificationMessage message;
	}
}
