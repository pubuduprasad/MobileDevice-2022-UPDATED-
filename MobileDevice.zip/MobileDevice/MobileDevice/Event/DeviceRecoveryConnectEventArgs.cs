﻿using System;
using MobileDevice.Enumerates;

namespace MobileDevice.Event
{
	// Token: 0x02000011 RID: 17
	public class DeviceRecoveryConnectEventArgs : EventArgs
	{
		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000FD RID: 253 RVA: 0x00004A58 File Offset: 0x00002C58
		public byte[] DevicePtr
		{
			get
			{
				return this.devicePtr;
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000FE RID: 254 RVA: 0x00004A70 File Offset: 0x00002C70
		public ConnectNotificationMessage Message
		{
			get
			{
				return this.message;
			}
		}

		// Token: 0x060000FF RID: 255 RVA: 0x00004A88 File Offset: 0x00002C88
		public DeviceRecoveryConnectEventArgs(byte[] devicePtr, ConnectNotificationMessage message)
		{
			this.devicePtr = devicePtr;
			this.message = message;
		}

		// Token: 0x04000036 RID: 54
		private byte[] devicePtr;

		// Token: 0x04000037 RID: 55
		private ConnectNotificationMessage message;
	}
}
