﻿using System;
using MobileDevice.Enumerates;

namespace MobileDevice.Event
{
	// Token: 0x02000013 RID: 19
	public class ListenErrorEventHandlerEventArgs : EventArgs
	{
		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000104 RID: 260 RVA: 0x00004AA0 File Offset: 0x00002CA0
		public string ErrorMessage
		{
			get
			{
				return this.errorMessage;
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000105 RID: 261 RVA: 0x00004AB8 File Offset: 0x00002CB8
		public ListenErrorEventType ErrorType
		{
			get
			{
				return this.errorType;
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00004AD0 File Offset: 0x00002CD0
		public ListenErrorEventHandlerEventArgs(string errorMessage, ListenErrorEventType errorType)
		{
			this.errorMessage = errorMessage;
			this.errorType = errorType;
		}

		// Token: 0x04000038 RID: 56
		private string errorMessage;

		// Token: 0x04000039 RID: 57
		private ListenErrorEventType errorType;
	}
}
