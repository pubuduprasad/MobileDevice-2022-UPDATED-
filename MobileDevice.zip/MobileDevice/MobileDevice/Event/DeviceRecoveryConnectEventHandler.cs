﻿using System;

namespace MobileDevice.Event
{
	// Token: 0x02000012 RID: 18
	// (Invoke) Token: 0x06000101 RID: 257
	public delegate void DeviceRecoveryConnectEventHandler(object sender, DeviceRecoveryConnectEventArgs args);
}
