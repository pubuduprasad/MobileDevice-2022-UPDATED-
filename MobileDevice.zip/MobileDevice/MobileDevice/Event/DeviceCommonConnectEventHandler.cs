﻿using System;

namespace MobileDevice.Event
{
	// Token: 0x02000010 RID: 16
	// (Invoke) Token: 0x060000FA RID: 250
	public delegate void DeviceCommonConnectEventHandler(object sender, DeviceCommonConnectEventArgs args);
}
