﻿using System;
using System.Collections.Generic;

namespace MobileDevice.Unitiy
{
	// Token: 0x02000006 RID: 6
	public static class EnumerableHelper
	{
		// Token: 0x060000B8 RID: 184 RVA: 0x00003EC4 File Offset: 0x000020C4
		public static void ForEach<T>(this IEnumerable<T> enumeration, Action<T> action)
		{
			foreach (T obj in enumeration)
			{
				action(obj);
			}
		}
	}
}
