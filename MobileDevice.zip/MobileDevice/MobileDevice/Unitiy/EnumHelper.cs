﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;

namespace MobileDevice.Unitiy
{
	// Token: 0x02000007 RID: 7
	public class EnumHelper
	{
		// Token: 0x060000B9 RID: 185 RVA: 0x00003F14 File Offset: 0x00002114
		public static string GetEnumDescription(Type enumType, object val)
		{
			string name = Enum.GetName(enumType, val);
			bool flag = string.IsNullOrEmpty(name);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				FieldInfo field = enumType.GetField(name);
				object[] customAttributes = field.GetCustomAttributes(typeof(DescriptionAttribute), true);
				bool flag2 = customAttributes.Length != 0;
				if (flag2)
				{
					DescriptionAttribute descriptionAttribute = customAttributes[0] as DescriptionAttribute;
					bool flag3 = descriptionAttribute != null;
					if (flag3)
					{
						return descriptionAttribute.Description;
					}
				}
				result = name;
			}
			return result;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00003F90 File Offset: 0x00002190
		public static IList<EnumInfo> GetEnumList<T>()
		{
			IList<EnumInfo> list = new List<EnumInfo>();
			Type typeFromHandle = typeof(T);
			foreach (object obj in Enum.GetValues(typeof(T)))
			{
				int num = (int)obj;
				EnumInfo enumInfo = new EnumInfo();
				enumInfo.Text = EnumHelper.GetEnumDescription(typeFromHandle, num);
				EnumInfo enumInfo2 = enumInfo;
				T model = EnumHelper.GetModel<T>(num);
				enumInfo2.Value = model.ToString();
				enumInfo.Value2 = num;
				list.Add(enumInfo);
			}
			return list;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00004058 File Offset: 0x00002258
		public static T GetModel<T>(int value)
		{
			return (T)((object)Enum.Parse(typeof(T), value.ToString(), true));
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00004088 File Offset: 0x00002288
		public static T GetModel<T>(string value)
		{
			return (T)((object)Enum.Parse(typeof(T), value.ToString(), true));
		}
	}
}
