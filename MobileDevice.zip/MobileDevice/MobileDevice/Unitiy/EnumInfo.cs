﻿using System;

namespace MobileDevice.Unitiy
{
	// Token: 0x02000008 RID: 8
	public class EnumInfo
	{
		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000BE RID: 190 RVA: 0x000040B7 File Offset: 0x000022B7
		// (set) Token: 0x060000BF RID: 191 RVA: 0x000040BF File Offset: 0x000022BF
		public string Text { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x000040C8 File Offset: 0x000022C8
		// (set) Token: 0x060000C1 RID: 193 RVA: 0x000040D0 File Offset: 0x000022D0
		public string Value { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000C2 RID: 194 RVA: 0x000040D9 File Offset: 0x000022D9
		// (set) Token: 0x060000C3 RID: 195 RVA: 0x000040E1 File Offset: 0x000022E1
		public int Value2 { get; set; }
	}
}
