﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.Callback
{
	// Token: 0x02000028 RID: 40
	// (Invoke) Token: 0x06000195 RID: 405
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void DeviceEventSink(IntPtr str, IntPtr user);
}
