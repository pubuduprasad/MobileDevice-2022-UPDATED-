﻿using System;
using System.Runtime.InteropServices;
using MobileDevice.Struct;

namespace MobileDevice.Callback
{
	// Token: 0x0200002A RID: 42
	// (Invoke) Token: 0x0600019D RID: 413
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void DeviceNotificationCallback(ref AMDeviceNotificationCallbackInfo callback_info);
}
