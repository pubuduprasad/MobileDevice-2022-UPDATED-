﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.Callback
{
	// Token: 0x02000029 RID: 41
	// (Invoke) Token: 0x06000199 RID: 409
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void DeviceInstallApplicationCallback(IntPtr dict);
}
