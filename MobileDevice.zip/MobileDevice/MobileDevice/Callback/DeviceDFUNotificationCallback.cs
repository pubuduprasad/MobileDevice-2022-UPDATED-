﻿using System;
using System.Runtime.InteropServices;
using MobileDevice.Struct;

namespace MobileDevice.Callback
{
	// Token: 0x02000027 RID: 39
	// (Invoke) Token: 0x06000191 RID: 401
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void DeviceDFUNotificationCallback(ref AMDFUModeDevice callback_info);
}
