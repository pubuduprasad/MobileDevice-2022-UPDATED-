﻿using System;
using System.Runtime.InteropServices;
using MobileDevice.Struct;

namespace MobileDevice.Callback
{
	// Token: 0x0200002B RID: 43
	// (Invoke) Token: 0x060001A1 RID: 417
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void DeviceRestoreNotificationCallback(ref AMRecoveryDevice callback_info);
}
