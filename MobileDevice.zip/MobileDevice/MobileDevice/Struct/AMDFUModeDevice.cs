﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.Struct
{
	// Token: 0x0200000D RID: 13
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	internal struct AMDFUModeDevice
	{
		// Token: 0x04000032 RID: 50
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
		public byte[] data;
	}
}
