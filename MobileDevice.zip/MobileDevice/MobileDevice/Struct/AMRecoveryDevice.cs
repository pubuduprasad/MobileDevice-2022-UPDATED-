﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.Struct
{
	// Token: 0x0200000E RID: 14
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct AMRecoveryDevice
	{
		// Token: 0x04000033 RID: 51
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
		public byte[] devicePtr;
	}
}
