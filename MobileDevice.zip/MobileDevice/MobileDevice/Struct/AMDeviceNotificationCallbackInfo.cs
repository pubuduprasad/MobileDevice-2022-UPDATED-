﻿using System;
using System.Runtime.InteropServices;
using MobileDevice.Enumerates;

namespace MobileDevice.Struct
{
	// Token: 0x0200000C RID: 12
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	internal struct AMDeviceNotificationCallbackInfo
	{
		// Token: 0x0400002F RID: 47
		internal IntPtr DevicePtr;

		// Token: 0x04000030 RID: 48
		public ConnectNotificationMessage Msg;

		// Token: 0x04000031 RID: 49
		public uint NotificationId;
	}
}
