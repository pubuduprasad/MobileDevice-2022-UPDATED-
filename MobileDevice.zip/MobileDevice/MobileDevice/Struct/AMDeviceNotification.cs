﻿using System;
using System.Runtime.InteropServices;
using MobileDevice.Callback;

namespace MobileDevice.Struct
{
	// Token: 0x0200000B RID: 11
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	internal struct AMDeviceNotification
	{
		// Token: 0x0400002A RID: 42
		private readonly uint unknown0;

		// Token: 0x0400002B RID: 43
		private readonly uint unknown1;

		// Token: 0x0400002C RID: 44
		private readonly uint unknown2;

		// Token: 0x0400002D RID: 45
		private readonly DeviceNotificationCallback callback;

		// Token: 0x0400002E RID: 46
		private readonly uint unknown3;
	}
}
