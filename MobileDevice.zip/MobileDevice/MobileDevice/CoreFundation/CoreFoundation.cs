﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000023 RID: 35
	public class CoreFoundation
	{
		// Token: 0x0600012B RID: 299 RVA: 0x00004F9C File Offset: 0x0000319C
		static CoreFoundation()
		{
			CoreFoundation.kCFStreamPropertyDataWritten = CoreFoundation.EnumToCFEnum("kCFStreamPropertyDataWritten");
			CoreFoundation.kCFTypeDictionaryKeyCallBacks = CoreFoundation.ConstToCFConst("kCFTypeDictionaryKeyCallBacks");
			CoreFoundation.kCFTypeDictionaryValueCallBacks = CoreFoundation.ConstToCFConst("kCFTypeDictionaryValueCallBacks");
			CoreFoundation.kCFTypeArrayCallBacks = CoreFoundation.ConstToCFConst("kCFTypeArrayCallBacks");
			CoreFoundation.kCFBooleanFalse = CFBoolean.GetCFBoolean(false);
			CoreFoundation.kCFBooleanTrue = CFBoolean.GetCFBoolean(true);
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0000506C File Offset: 0x0000326C
		internal static IntPtr EnumToCFStreamPropertyDataWritten()
		{
			bool flag = CoreFoundation.kCFStreamPropertyDataWritten == IntPtr.Zero;
			if (flag)
			{
				IntPtr moduleHandle = CoreFoundation.GetModuleHandle("CoreFoundation.dll");
				bool flag2 = moduleHandle == IntPtr.Zero;
				if (flag2)
				{
					CoreFoundation.kCFStreamPropertyDataWritten = Marshal.ReadIntPtr(CoreFoundation.kCFStreamPropertyDataWritten, 0);
				}
				else
				{
					CoreFoundation.kCFStreamPropertyDataWritten = CoreFoundation.GetProcAddress(moduleHandle, "kCFStreamPropertyDataWritten");
				}
			}
			return CoreFoundation.kCFStreamPropertyDataWritten;
		}

		// Token: 0x0600012D RID: 301 RVA: 0x000050D8 File Offset: 0x000032D8
		internal static IntPtr EnumToCFEnum(string enmName)
		{
			IntPtr ptr = IntPtr.Zero;
			IntPtr moduleHandle = CoreFoundation.GetModuleHandle("CoreFoundation.dll");
			bool flag = moduleHandle != IntPtr.Zero;
			if (flag)
			{
				ptr = CoreFoundation.GetProcAddress(moduleHandle, enmName);
			}
			return Marshal.ReadIntPtr(ptr, 0);
		}

		// Token: 0x0600012E RID: 302 RVA: 0x0000511C File Offset: 0x0000331C
		public static IntPtr ConstToCFConst(string constName)
		{
			IntPtr ptr = IntPtr.Zero;
			IntPtr moduleHandle = CoreFoundation.GetModuleHandle("CoreFoundation.dll");
			bool flag = moduleHandle != IntPtr.Zero;
			if (flag)
			{
				ptr = CoreFoundation.GetProcAddress(moduleHandle, constName);
			}
			return Marshal.ReadIntPtr(ptr, 0);
		}

		// Token: 0x0600012F RID: 303 RVA: 0x00005160 File Offset: 0x00003360
		public static string CreatePlistString(object objPlist)
		{
			string result = string.Empty;
			try
			{
				IntPtr propertyList = CoreFoundation.CFTypeFromManagedType(objPlist);
				IntPtr intPtr = CoreFoundation.CFWriteStreamCreateWithAllocatedBuffers(IntPtr.Zero, IntPtr.Zero);
				bool flag = !(intPtr != IntPtr.Zero) || !CoreFoundation.CFWriteStreamOpen(intPtr);
				if (flag)
				{
					return result;
				}
				IntPtr zero = IntPtr.Zero;
				bool flag2 = CoreFoundation.CFPropertyListWriteToStream(propertyList, intPtr, CFPropertyListFormat.kCFPropertyListXMLFormat_v1_0, ref zero) > 0;
				if (flag2)
				{
					IntPtr propertyName = CoreFoundation.kCFStreamPropertyDataWritten;
					IntPtr intPtr2 = CoreFoundation.CFWriteStreamCopyProperty(intPtr, propertyName);
					bool flag3 = CoreFoundation.CFDataGetLength(intPtr2) > 0;
					if (flag3)
					{
						byte[] bytes = CoreFoundation.ReadCFDataFromIntPtr(intPtr2);
						result = Encoding.UTF8.GetString(bytes).Replace("\0", string.Empty);
					}
					CoreFoundation.CFRelease(intPtr2);
				}
				CoreFoundation.CFWriteStreamClose(intPtr);
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x06000130 RID: 304
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x06000131 RID: 305
		[DllImport("kernel32.dll", SetLastError = true)]
		public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

		// Token: 0x06000132 RID: 306
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "__CFStringMakeConstantString")]
		internal static extern IntPtr CFStringMakeConstantString(string cStr);

		// Token: 0x06000133 RID: 307
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFAbsoluteTimeGetGregorianDate(ref double at, ref IntPtr tz);

		// Token: 0x06000134 RID: 308
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int CFArrayGetCount(IntPtr sourceRef);

		// Token: 0x06000135 RID: 309
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFArrayGetTypeID();

		// Token: 0x06000136 RID: 310
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern void CFArrayGetValues(IntPtr sourceRef, CFRange range, IntPtr values);

		// Token: 0x06000137 RID: 311
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFBooleanGetTypeID();

		// Token: 0x06000138 RID: 312
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFDateCreate(IntPtr intptr_2, double double_0);

		// Token: 0x06000139 RID: 313
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFDataCreate(IntPtr intptr_2, IntPtr intptr_3, int int_1);

		// Token: 0x0600013A RID: 314
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern bool CFBooleanGetValue(IntPtr sourceRef);

		// Token: 0x0600013B RID: 315
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern void CFDataAppendBytes(IntPtr theData, IntPtr pointer, uint length);

		// Token: 0x0600013C RID: 316
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFDataCreateMutable(IntPtr allocator, uint capacity);

		// Token: 0x0600013D RID: 317
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFDataGetBytePtr(IntPtr sourceRef);

		// Token: 0x0600013E RID: 318
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern void CFDataGetBytes(IntPtr theData, CFRange range, byte[] buffer);

		// Token: 0x0600013F RID: 319
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern int CFDataGetLength(IntPtr sourceRef);

		// Token: 0x06000140 RID: 320
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFDataGetTypeID();

		// Token: 0x06000141 RID: 321
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern double CFDateGetAbsoluteTime(IntPtr sourceRef);

		// Token: 0x06000142 RID: 322
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFDateGetTypeID();

		// Token: 0x06000143 RID: 323
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		internal static extern void CFDictionaryAddValue(IntPtr theDict, IntPtr keys, IntPtr values);

		// Token: 0x06000144 RID: 324
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
		internal static extern IntPtr CFDictionaryCreate(IntPtr allocator, ref IntPtr keys, ref IntPtr values, int numValues, IntPtr CFDictionaryKeyCallBacks, IntPtr CFDictionaryValueCallBacks);

		// Token: 0x06000145 RID: 325
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFDictionaryCreateMutable(IntPtr allocator, int capacity, IntPtr CFDictionaryKeyCallBacks, IntPtr CFDictionaryValueCallBacks);

		// Token: 0x06000146 RID: 326 RVA: 0x00005248 File Offset: 0x00003448
		public static IntPtr CFDictionaryFromManagedDictionary(Dictionary<object, object> sourceDict)
		{
			bool flag = sourceDict == null;
			IntPtr result;
			if (flag)
			{
				result = IntPtr.Zero;
			}
			else
			{
				IntPtr intPtr = IntPtr.Zero;
				try
				{
					intPtr = CoreFoundation.CFDictionaryCreateMutable(CoreFoundation.kCFAllocatorDefault, sourceDict.Count, CoreFoundation.kCFTypeDictionaryKeyCallBacks, CoreFoundation.kCFTypeDictionaryValueCallBacks);
					foreach (KeyValuePair<object, object> keyValuePair in sourceDict)
					{
						IntPtr intPtr2 = CoreFoundation.CFTypeFromManagedType(keyValuePair.Key);
						IntPtr intPtr3 = CoreFoundation.CFTypeFromManagedType(keyValuePair.Value);
						bool flag2 = intPtr2 != IntPtr.Zero && intPtr3 != IntPtr.Zero;
						if (flag2)
						{
							CoreFoundation.CFDictionaryAddValue(intPtr, intPtr2, intPtr3);
						}
					}
				}
				catch
				{
				}
				result = intPtr;
			}
			return result;
		}

		// Token: 0x06000147 RID: 327
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFWriteStreamCreateWithAllocatedBuffers(IntPtr intptr_2, IntPtr intptr_3);

		// Token: 0x06000148 RID: 328
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern int CFPropertyListWriteToStream(IntPtr propertyList, IntPtr stream, CFPropertyListFormat format, ref IntPtr errorString);

		// Token: 0x06000149 RID: 329
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern bool CFWriteStreamOpen(IntPtr intptr_2);

		// Token: 0x0600014A RID: 330
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr CFNumberCreate(IntPtr intptr_2, CFNumberType enum20_0, IntPtr intptr_3);

		// Token: 0x0600014B RID: 331
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr CFNumberCreate_Int16(IntPtr number, CFNumberType theType, ref short valuePtr);

		// Token: 0x0600014C RID: 332
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberCreate")]
		public static extern IntPtr CFNumberCreate_Int32(IntPtr number, CFNumberType theType, ref int valuePtr);

		// Token: 0x0600014D RID: 333
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberCreate")]
		public static extern IntPtr CFNumberCreate_Int64(IntPtr number, CFNumberType theType, ref long valuePtr);

		// Token: 0x0600014E RID: 334
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberCreate")]
		public static extern IntPtr CFNumberCreate_Float(IntPtr number, CFNumberType theType, ref float valuePtr);

		// Token: 0x0600014F RID: 335
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberCreate")]
		public static extern IntPtr CFNumberCreate_Double(IntPtr number, CFNumberType theType, ref double valuePtr);

		// Token: 0x06000150 RID: 336 RVA: 0x00005330 File Offset: 0x00003530
		internal static IntPtr CFNumberCreateNumbers(object objVals)
		{
			Type type = objVals.GetType();
			bool flag = type == typeof(short);
			IntPtr result;
			if (flag)
			{
				short num = Convert.ToInt16(objVals);
				result = CoreFoundation.CFNumberCreate_Int16(CoreFoundation.kCFAllocatorDefault, CFNumberType.kCFNumberSInt16Type, ref num);
			}
			else
			{
				bool flag2 = type == typeof(int) || type == typeof(ushort);
				if (flag2)
				{
					int num2 = Convert.ToInt32(objVals);
					result = CoreFoundation.CFNumberCreate_Int32(CoreFoundation.kCFAllocatorDefault, CFNumberType.kCFNumberSInt32Type, ref num2);
				}
				else
				{
					bool flag3 = type == typeof(long) || type == typeof(uint);
					if (flag3)
					{
						long num3 = Convert.ToInt64(objVals);
						result = CoreFoundation.CFNumberCreate_Int64(CoreFoundation.kCFAllocatorDefault, CFNumberType.kCFNumberSInt64Type, ref num3);
					}
					else
					{
						bool flag4 = type == typeof(float);
						if (flag4)
						{
							float num4 = Convert.ToSingle(objVals);
							result = CoreFoundation.CFNumberCreate_Float(CoreFoundation.kCFAllocatorDefault, CFNumberType.kCFNumberFloat32Type, ref num4);
						}
						else
						{
							bool flag5 = type != typeof(double);
							if (flag5)
							{
								throw new NotImplementedException();
							}
							double num5 = Convert.ToDouble(objVals);
							result = CoreFoundation.CFNumberCreate_Double(CoreFoundation.kCFAllocatorDefault, CFNumberType.kCFNumberFloat64Type, ref num5);
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000151 RID: 337 RVA: 0x0000546C File Offset: 0x0000366C
		public static IntPtr CFTypeFromManagedType(object objVal)
		{
			bool flag = objVal == null;
			IntPtr result;
			if (flag)
			{
				result = IntPtr.Zero;
			}
			else
			{
				IntPtr intPtr = IntPtr.Zero;
				Type type = objVal.GetType();
				try
				{
					bool flag2 = type == typeof(string);
					if (flag2)
					{
						return CoreFoundation.StringToCFString((string)objVal);
					}
					bool flag3 = type == typeof(short) || type == typeof(ushort) || type == typeof(int) || type == typeof(uint) || type == typeof(long) || type == typeof(double) || type == typeof(float);
					if (flag3)
					{
						return CoreFoundation.CFNumberCreateNumbers(objVal);
					}
					bool flag4 = type == typeof(bool);
					if (flag4)
					{
						return CFBoolean.GetCFBoolean(Convert.ToBoolean(objVal));
					}
					bool flag5 = type == typeof(DateTime);
					if (flag5)
					{
						string date = new DateTime(2001, 1, 1, 0, 0, 0, 0).ToString();
						string date2 = Convert.ToString(objVal);
						double double_ = (double)DateAndTime.DateDiff("s", date, date2, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1);
						return CoreFoundation.CFDateCreate(CoreFoundation.kCFAllocatorDefault, double_);
					}
					bool flag6 = type == typeof(byte[]);
					if (flag6)
					{
						byte[] array = objVal as byte[];
						IntPtr pointer = Marshal.UnsafeAddrOfPinnedArrayElement(array, 0);
						intPtr = CoreFoundation.CFDataCreateMutable(CoreFoundation.kCFAllocatorDefault, (uint)array.Length);
						CoreFoundation.CFDataAppendBytes(intPtr, pointer, (uint)array.Length);
						return intPtr;
					}
					bool flag7 = type == typeof(object[]);
					if (flag7)
					{
						return CoreFoundation.CFArrayFromManageArray((object[])objVal);
					}
					bool flag8 = type == typeof(ArrayList);
					if (flag8)
					{
						return CoreFoundation.CFArrayFromManageArrayList(objVal as ArrayList);
					}
					bool flag9 = type == typeof(List<object>);
					if (flag9)
					{
						return CoreFoundation.CFArrayFromManageList(objVal as List<object>);
					}
					bool flag10 = type == typeof(Dictionary<object, object>);
					if (flag10)
					{
						intPtr = CoreFoundation.CFDictionaryFromManagedDictionary(objVal as Dictionary<object, object>);
					}
				}
				catch
				{
				}
				result = intPtr;
			}
			return result;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x000056E8 File Offset: 0x000038E8
		public static IntPtr CFArrayFromManageList(IList<object> arrySrc)
		{
			bool flag = arrySrc == null;
			IntPtr result;
			if (flag)
			{
				result = IntPtr.Zero;
			}
			else
			{
				IntPtr intPtr = CoreFoundation.CFArrayCreateMutable(CoreFoundation.kCFAllocatorDefault, arrySrc.Count, CoreFoundation.kCFTypeArrayCallBacks);
				foreach (object obj in arrySrc)
				{
					bool flag2 = obj != null;
					if (flag2)
					{
						CoreFoundation.CFArrayAppendValue(intPtr, CoreFoundation.CFTypeFromManagedType(obj));
					}
				}
				result = intPtr;
			}
			return result;
		}

		// Token: 0x06000153 RID: 339 RVA: 0x00005778 File Offset: 0x00003978
		public static IntPtr CFArrayFromManageArrayList(ArrayList arrySrc)
		{
			bool flag = arrySrc == null;
			IntPtr result;
			if (flag)
			{
				result = IntPtr.Zero;
			}
			else
			{
				IntPtr intPtr = CoreFoundation.CFArrayCreateMutable(CoreFoundation.kCFAllocatorDefault, arrySrc.Count, CoreFoundation.kCFTypeArrayCallBacks);
				IEnumerator enumerator = arrySrc.GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						bool flag2 = obj != null;
						if (flag2)
						{
							CoreFoundation.CFArrayAppendValue(intPtr, CoreFoundation.CFTypeFromManagedType(obj));
						}
					}
				}
				finally
				{
					IDisposable disposable = enumerator as IDisposable;
					bool flag3 = disposable != null;
					if (flag3)
					{
						disposable.Dispose();
					}
				}
				result = intPtr;
			}
			return result;
		}

		// Token: 0x06000154 RID: 340
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFArrayCreateMutable(IntPtr allocator, int capacity, IntPtr callback);

		// Token: 0x06000155 RID: 341 RVA: 0x00005820 File Offset: 0x00003A20
		public static IntPtr CFArrayFromManageArray(object[] arrySrc)
		{
			bool flag = arrySrc == null;
			IntPtr result;
			if (flag)
			{
				result = IntPtr.Zero;
			}
			else
			{
				IntPtr intPtr = IntPtr.Zero;
				try
				{
					intPtr = CoreFoundation.CFArrayCreateMutable(CoreFoundation.kCFAllocatorDefault, arrySrc.Length, CoreFoundation.kCFTypeArrayCallBacks);
					foreach (object obj in arrySrc)
					{
						bool flag2 = obj != null;
						if (flag2)
						{
							CoreFoundation.CFArrayAppendValue(intPtr, CoreFoundation.CFTypeFromManagedType(obj));
						}
					}
				}
				catch
				{
				}
				result = intPtr;
			}
			return result;
		}

		// Token: 0x06000156 RID: 342
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFArrayAppendValue(IntPtr intptr_2, IntPtr intptr_3);

		// Token: 0x06000157 RID: 343
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int CFDictionaryGetCount(IntPtr sourceRef);

		// Token: 0x06000158 RID: 344
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern void CFDictionaryGetKeysAndValues(IntPtr sourceRef, IntPtr keys, IntPtr values);

		// Token: 0x06000159 RID: 345
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFDictionaryGetTypeID();

		// Token: 0x0600015A RID: 346
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFGetTypeID(IntPtr cf);

		// Token: 0x0600015B RID: 347
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern CFNumberType CFNumberGetType(IntPtr sourceRef);

		// Token: 0x0600015C RID: 348
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFNumberGetTypeID();

		// Token: 0x0600015D RID: 349
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberGetValue", SetLastError = true)]
		internal static extern bool CFNumberGetValue_Float(IntPtr number, CFNumberType theType, ref float valuePtr);

		// Token: 0x0600015E RID: 350
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberGetValue")]
		internal static extern bool CFNumberGetValue_Double(IntPtr number, CFNumberType theType, ref double valuePtr);

		// Token: 0x0600015F RID: 351
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberGetValue")]
		internal static extern bool CFNumberGetValue_Int(IntPtr number, CFNumberType theType, ref int valuePtr);

		// Token: 0x06000160 RID: 352
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberGetValue")]
		internal static extern bool CFNumberGetValue_Long(IntPtr number, CFNumberType theType, ref long valuePtr);

		// Token: 0x06000161 RID: 353
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFNumberGetValue")]
		internal static extern bool CFNumberGetValue_Single(IntPtr number, CFNumberType theType, ref float valuePtr);

		// Token: 0x06000162 RID: 354
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFPropertyListCreateFromXMLData(IntPtr allocator, IntPtr xmlData, CFPropertyListMutabilityOptions mutabilityOption, ref IntPtr errorString);

		// Token: 0x06000163 RID: 355
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "CFPropertyListCreateFromXMLData")]
		internal static extern IntPtr CFPropertyListCreatePtrFromXMLData(IntPtr allocator, IntPtr datas, CFPropertyListMutabilityOptions option, ref IntPtr errorString);

		// Token: 0x06000164 RID: 356
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern IntPtr CFPropertyListCreateXMLData(IntPtr allocator, IntPtr theData);

		// Token: 0x06000165 RID: 357
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern bool CFPropertyListIsValid(IntPtr theData, CFPropertyListFormat format);

		// Token: 0x06000166 RID: 358 RVA: 0x000058B0 File Offset: 0x00003AB0
		private static IntPtr CFRangeMake(int loc, int len)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(8);
			Marshal.WriteInt32(intPtr, 0, loc);
			Marshal.WriteInt32(intPtr, 4, len);
			return intPtr;
		}

		// Token: 0x06000167 RID: 359
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern void CFRelease(IntPtr cf);

		// Token: 0x06000168 RID: 360
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
		internal static extern IntPtr CFRetain(IntPtr obj);

		// Token: 0x06000169 RID: 361
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFStringCreateFromExternalRepresentation(IntPtr allocator, IntPtr data, CFStringEncoding encoding);

		// Token: 0x0600016A RID: 362
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFStringCreateWithBytes(IntPtr allocator, byte[] data, ulong numBytes, CFStringEncoding encoding, bool isExternalRepresentation);

		// Token: 0x0600016B RID: 363
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
		internal static extern IntPtr CFStringGetCharacters(IntPtr handle, CFRange range, IntPtr buffer);

		// Token: 0x0600016C RID: 364
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr CFStringCreateWithCharacters(IntPtr allocator, [MarshalAs(UnmanagedType.LPWStr)] string stingData, int strLength);

		// Token: 0x0600016D RID: 365
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFStringCreateWithBytesNoCopy(IntPtr allocator, byte[] data, ulong numBytes, CFStringEncoding encoding, bool isExternalRepresentation, IntPtr contentsDeallocator);

		// Token: 0x0600016E RID: 366
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFStringCreateWithCString(IntPtr allocator, string data, CFStringEncoding encoding);

		// Token: 0x0600016F RID: 367
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern CFRange CFStringFind(IntPtr theString, IntPtr stringToFind, ushort compareOptions);

		// Token: 0x06000170 RID: 368
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
		internal static extern IntPtr CFStringGetCharactersPtr(IntPtr handle);

		// Token: 0x06000171 RID: 369
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern int CFStringGetBytes(IntPtr theString, CFRange range, uint encoding, byte lossByte, byte isExternalRepresentation, byte[] buffer, int maxBufLen, ref int usedBufLen);

		// Token: 0x06000172 RID: 370
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern char CFStringGetCharacterAtIndex(IntPtr theString, int idx);

		// Token: 0x06000173 RID: 371
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		internal static extern int CFStringGetLength(IntPtr cf);

		// Token: 0x06000174 RID: 372
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern int CFStringGetMaximumSizeForEncoding(int length, uint encoding);

		// Token: 0x06000175 RID: 373
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr CFWriteStreamCopyProperty(IntPtr stream, IntPtr propertyName);

		// Token: 0x06000176 RID: 374
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool CFWriteStreamClose(IntPtr stream);

		// Token: 0x06000177 RID: 375
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern uint CFStringGetTypeID();

		// Token: 0x06000178 RID: 376 RVA: 0x000058DC File Offset: 0x00003ADC
		public static string CFStringToString(byte[] value)
		{
			bool flag = value.Length > 9;
			string result;
			if (flag)
			{
				result = Encoding.UTF8.GetString(value, 9, (int)value[9]);
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000179 RID: 377
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFTimeZoneCopySystem();

		// Token: 0x0600017A RID: 378
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern bool CFURLCreateDataAndPropertiesFromResource(IntPtr allocator, IntPtr urlRef, ref IntPtr resourceData, ref IntPtr properties, IntPtr desiredProperties, ref int errorCode);

		// Token: 0x0600017B RID: 379
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr CFURLCreateWithFileSystemPath(IntPtr allocator, IntPtr stringRef, CFURLPathStyle pathStyle, bool isDirectory);

		// Token: 0x0600017C RID: 380
		[DllImport("CoreFoundation.dll", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool CFURLWriteDataAndPropertiesToResource(IntPtr urlRef, IntPtr dataToWrite, IntPtr propertiesToWrite, ref int errorCode);

		// Token: 0x0600017D RID: 381 RVA: 0x00005914 File Offset: 0x00003B14
		public static object ManagedPropertyListFromXMLData(byte[] inBytes)
		{
			bool flag = inBytes != null;
			if (flag)
			{
				IntPtr intPtr = CoreFoundation.CFDataCreateMutable(CoreFoundation.kCFAllocatorDefault, (uint)inBytes.Length);
				IntPtr pointer = Marshal.UnsafeAddrOfPinnedArrayElement(inBytes, 0);
				CoreFoundation.CFDataAppendBytes(intPtr, pointer, (uint)inBytes.Length);
				IntPtr zero = IntPtr.Zero;
				IntPtr value = CoreFoundation.CFPropertyListCreatePtrFromXMLData(CoreFoundation.kCFAllocatorDefault, intPtr, CFPropertyListMutabilityOptions.kCFPropertyListImmutable, ref zero);
				bool flag2 = value != IntPtr.Zero;
				if (flag2)
				{
					return CoreFoundation.ManagedTypeFromCFType(ref value);
				}
			}
			return null;
		}

		// Token: 0x0600017E RID: 382 RVA: 0x00005988 File Offset: 0x00003B88
		public static object ManagedPropertyListFromXMLData(string fileOnPC)
		{
			byte[] array = new byte[0];
			using (FileStream fileStream = new FileStream(fileOnPC, FileMode.Open))
			{
				array = new byte[fileStream.Length];
				fileStream.Read(array, 0, (int)fileStream.Length);
			}
			return CoreFoundation.ManagedPropertyListFromXMLData(array);
		}

		// Token: 0x0600017F RID: 383 RVA: 0x000059EC File Offset: 0x00003BEC
		public static object ManagedTypeFromCFType(ref IntPtr srcRef)
		{
			bool flag = srcRef == IntPtr.Zero;
			object result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				uint num = CoreFoundation.CFGetTypeID(srcRef);
				object obj = null;
				try
				{
					bool flag2 = num == CoreFoundation.CFStringGetTypeID();
					if (flag2)
					{
						obj = CoreFoundation.ReadCFStringFromIntPtr(srcRef);
					}
					else
					{
						bool flag3 = num == CoreFoundation.CFArrayGetTypeID();
						if (flag3)
						{
							obj = CoreFoundation.ReadCFArrayFromIntPtr(srcRef);
						}
						else
						{
							bool flag4 = num == CoreFoundation.CFNumberGetTypeID();
							if (flag4)
							{
								obj = CoreFoundation.ReadCFNumberFromIntPtr(srcRef);
							}
							else
							{
								bool flag5 = num == CoreFoundation.CFDateGetTypeID();
								if (flag5)
								{
									obj = CoreFoundation.ReadCFDateFromIntPtr(srcRef);
								}
								else
								{
									bool flag6 = num == CoreFoundation.CFBooleanGetTypeID();
									if (flag6)
									{
										obj = CoreFoundation.CFBooleanGetValue(srcRef);
									}
									else
									{
										bool flag7 = num == CoreFoundation.CFDictionaryGetTypeID();
										if (flag7)
										{
											obj = CoreFoundation.ReadCFDictionaryFromIntPtr(srcRef);
										}
										else
										{
											bool flag8 = num == CoreFoundation.CFDataGetTypeID();
											if (flag8)
											{
												obj = CoreFoundation.ReadCFDataFromIntPtr(srcRef);
											}
											else
											{
												obj = CoreFoundation.ReadCFStringFromIntPtr(srcRef);
												bool flag9 = obj == null;
												if (flag9)
												{
													obj = CoreFoundation.ReadCFDateFromIntPtr(srcRef);
												}
											}
										}
									}
								}
							}
						}
					}
				}
				catch 
				{
				}
				bool flag10 = obj == null;
				if (flag10)
				{
					result = string.Empty;
				}
				else
				{
					result = obj;
				}
			}
			return result;
		}

		// Token: 0x06000180 RID: 384 RVA: 0x00005B40 File Offset: 0x00003D40
		public static string PropertyListToXML(byte[] propertyList)
		{
			try
			{
				int num = propertyList.Length;
				bool flag = propertyList[0] == 98 && propertyList[1] == 112 && propertyList[2] == 108 && propertyList[3] == 105 && propertyList[4] == 115 && propertyList[5] == 116 && propertyList[6] == 48 && propertyList[7] == 48;
				if (flag)
				{
					IntPtr zero = IntPtr.Zero;
					IntPtr intPtr = IntPtr.Zero;
					intPtr = CoreFoundation.CFPropertyListCreateFromXMLData(IntPtr.Zero, intPtr, CFPropertyListMutabilityOptions.kCFPropertyListImmutable, ref zero);
					bool flag2 = intPtr != IntPtr.Zero;
					if (flag2)
					{
						intPtr = CoreFoundation.CFPropertyListCreateXMLData(IntPtr.Zero, intPtr);
						num = CoreFoundation.CFDataGetLength(intPtr) - 1;
						propertyList = new byte[num + 1];
						CFRange range = new CFRange(0, num);
						CoreFoundation.CFDataGetBytes(intPtr, range, propertyList);
					}
				}
				return Encoding.UTF8.GetString(propertyList);
			}
			catch  
			{
			}
			return null;
		}

		// Token: 0x06000181 RID: 385 RVA: 0x00005C20 File Offset: 0x00003E20
		internal static object ReadCFArrayFromIntPtr(IntPtr srcRef)
		{
			bool flag = srcRef == IntPtr.Zero;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int num = CoreFoundation.CFArrayGetCount(srcRef);
				bool flag2 = num <= 0;
				if (flag2)
				{
					result = null;
				}
				else
				{
					object[] array = new object[num];
					IntPtr intPtr = Marshal.AllocCoTaskMem(num * 4 * 2);
					CoreFoundation.CFArrayGetValues(srcRef, new CFRange(0, num), intPtr);
					for (int i = 0; i < num; i++)
					{
						IntPtr intPtr2 = Marshal.ReadIntPtr(intPtr, i * 4 * 2);
						array[i] = CoreFoundation.ManagedTypeFromCFType(ref intPtr2);
					}
					Marshal.FreeCoTaskMem(intPtr);
					result = array;
				}
			}
			return result;
		}

		// Token: 0x06000182 RID: 386 RVA: 0x00005CC0 File Offset: 0x00003EC0
		internal static byte[] ReadCFDataFromIntPtr(IntPtr srcRef)
		{
			bool flag = srcRef == IntPtr.Zero;
			byte[] result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int num = CoreFoundation.CFDataGetLength(srcRef);
				bool flag2 = num <= 0;
				if (flag2)
				{
					result = null;
				}
				else
				{
					IntPtr ptr = CoreFoundation.CFDataGetBytePtr(srcRef);
					byte[] array = new byte[num];
					for (int i = 0; i < num; i++)
					{
						array[i] = Marshal.ReadByte(ptr, i);
					}
					result = array;
				}
			}
			return result;
		}

		// Token: 0x06000183 RID: 387 RVA: 0x00005D38 File Offset: 0x00003F38
		internal static DateTime ReadCFDateFromIntPtr(IntPtr srcRef)
		{
			DateTime result = DateTime.MinValue;
			bool flag = srcRef != IntPtr.Zero;
			if (flag)
			{
				double value = CoreFoundation.CFDateGetAbsoluteTime(srcRef);
				result = new DateTime(2001, 1, 1, 0, 0, 0).AddSeconds(value);
			}
			return result;
		}

		// Token: 0x06000184 RID: 388 RVA: 0x00005D84 File Offset: 0x00003F84
		public static object ReadCFDictionaryFromIntPtr(IntPtr srcRef)
		{
			bool flag = srcRef == IntPtr.Zero;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int num = CoreFoundation.CFDictionaryGetCount(srcRef);
				bool flag2 = num <= 0;
				if (flag2)
				{
					result = null;
				}
				else
				{
					IntPtr intPtr = Marshal.AllocCoTaskMem(num * 4 * 2);
					IntPtr ptr = Marshal.AllocCoTaskMem(num * 4 * 2);
					CFDictionary.GetKeysAndValues(srcRef, intPtr, ref ptr);
					Dictionary<object, object> dictionary = new Dictionary<object, object>();
					for (int i = 0; i < num; i++)
					{
						IntPtr intPtr2 = Marshal.ReadIntPtr(intPtr, i * 4 * 2);
						IntPtr intPtr3 = Marshal.ReadIntPtr(ptr, i * 4 * 2);
						object key = CoreFoundation.ManagedTypeFromCFType(ref intPtr2);
						object value = CoreFoundation.ManagedTypeFromCFType(ref intPtr3);
						dictionary.Add(key, value);
					}
					result = dictionary;
				}
			}
			return result;
		}

		// Token: 0x06000185 RID: 389 RVA: 0x00005E44 File Offset: 0x00004044
		public static object ReadCFNumberFromIntPtr(IntPtr srcRef)
		{
			bool flag = srcRef == IntPtr.Zero;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				object obj = null;
				switch (CoreFoundation.CFNumberGetType(srcRef))
				{
				case CFNumberType.kCFNumberSInt8Type:
				case CFNumberType.kCFNumberSInt16Type:
				case CFNumberType.kCFNumberSInt32Type:
				case CFNumberType.kCFNumberCharType:
				case CFNumberType.kCFNumberShortType:
				case CFNumberType.kCFNumberIntType:
				case CFNumberType.kCFNumberLongType:
				case CFNumberType.kCFNumberCFIndexType:
				case CFNumberType.kCFNumberNSIntegerType:
				{
					int num = 0;
					bool flag2 = CoreFoundation.CFNumberGetValue_Int(srcRef, CFNumberType.kCFNumberIntType, ref num);
					if (flag2)
					{
						obj = num;
					}
					return obj;
				}
				case CFNumberType.kCFNumberSInt64Type:
				case CFNumberType.kCFNumberLongLongType:
				{
					long num2 = 0L;
					bool flag3 = CoreFoundation.CFNumberGetValue_Long(srcRef, CFNumberType.kCFNumberSInt64Type, ref num2);
					if (flag3)
					{
						obj = num2;
					}
					break;
				}
				case CFNumberType.kCFNumberFloat32Type:
				case CFNumberType.kCFNumberFloatType:
				case CFNumberType.kCFNumberCGFloatType:
				{
					float num3 = 0f;
					bool flag4 = CoreFoundation.CFNumberGetValue_Float(srcRef, CFNumberType.kCFNumberFloatType, ref num3);
					if (flag4)
					{
						obj = num3;
					}
					return obj;
				}
				case CFNumberType.kCFNumberFloat64Type:
				case CFNumberType.kCFNumberDoubleType:
				{
					double num4 = 0.0;
					bool flag5 = CoreFoundation.CFNumberGetValue_Double(srcRef, CFNumberType.kCFNumberDoubleType, ref num4);
					if (flag5)
					{
						obj = num4;
					}
					return obj;
				}
				}
				result = obj;
			}
			return result;
		}

		// Token: 0x06000186 RID: 390 RVA: 0x00005F5C File Offset: 0x0000415C
		public static string ReadCFStringFromIntPtr(IntPtr srcRef)
		{
			bool flag = srcRef == IntPtr.Zero;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = CFString.FetchString(srcRef);
			}
			return result;
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00005F88 File Offset: 0x00004188
		public static object ReadPlist_managed(string fileOnPC)
		{
			object result = null;
			try
			{
				IntPtr intPtr = IntPtr.Zero;
				int num = 0;
				using (FileStream fileStream = new FileStream(fileOnPC, FileMode.Open, FileAccess.Read))
				{
					num = (int)fileStream.Length;
					intPtr = Marshal.AllocCoTaskMem(num);
					byte[] array = new byte[num];
					fileStream.Read(array, 0, array.Length);
					Marshal.Copy(array, 0, intPtr, array.Length);
				}
				IntPtr intPtr2 = IntPtr.Zero;
				IntPtr intPtr3 = IntPtr.Zero;
				IntPtr zero = IntPtr.Zero;
				intPtr2 = CoreFoundation.CFDataCreate(CoreFoundation.kCFAllocatorDefault, intPtr, num);
				bool flag = intPtr2 != IntPtr.Zero;
				if (flag)
				{
					intPtr3 = CoreFoundation.CFPropertyListCreateFromXMLData(CoreFoundation.kCFAllocatorDefault, intPtr2, CFPropertyListMutabilityOptions.kCFPropertyListImmutable, ref zero);
					bool flag2 = intPtr3 == IntPtr.Zero;
					if (flag2)
					{
						return null;
					}
				}
				bool flag3 = intPtr2 != IntPtr.Zero;
				if (flag3)
				{
					try
					{
						CoreFoundation.CFRelease(intPtr2);
					}
					catch
					{
					}
				}
				bool flag4 = intPtr != IntPtr.Zero;
				if (flag4)
				{
					Marshal.FreeCoTaskMem(intPtr);
				}
				result = CoreFoundation.ManagedTypeFromCFType(ref intPtr3);
				bool flag5 = intPtr3 != IntPtr.Zero;
				if (flag5)
				{
					CoreFoundation.CFRelease(intPtr3);
				}
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x0000610C File Offset: 0x0000430C
		public static string SearchXmlByKey(string xmlText, string xmlKey)
		{
			string text = "";
			int num = Strings.InStr(xmlText, xmlKey, CompareMethod.Binary);
			bool flag = num > 0;
			if (flag)
			{
				int num2 = Strings.InStr(num, xmlText, "<string>", CompareMethod.Binary);
				bool flag2 = num2 > num;
				if (flag2)
				{
					num2 += "<string>".Length;
					num = Strings.InStr(num2, xmlText, "</string>", CompareMethod.Binary);
					bool flag3 = num > num2;
					if (flag3)
					{
						text = Strings.Mid(xmlText, num2, num - num2);
					}
				}
			}
			return text.Trim();
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00006190 File Offset: 0x00004390
		public static IntPtr StringToCFString(string values)
		{
			IntPtr result = IntPtr.Zero;
			bool flag = values != null;
			if (flag)
			{
				byte[] bytes = Encoding.UTF8.GetBytes(values);
				int num = bytes.Length;
				IntPtr intPtr = CoreFoundation.CFDataCreateMutable(IntPtr.Zero, (uint)num);
				IntPtr pointer = Marshal.UnsafeAddrOfPinnedArrayElement(bytes, 0);
				CoreFoundation.CFDataAppendBytes(intPtr, pointer, (uint)num);
				result = CoreFoundation.CFStringCreateFromExternalRepresentation(IntPtr.Zero, intPtr, (CFStringEncoding)134217984);
			}
			return result;
		}

		// Token: 0x0600018A RID: 394 RVA: 0x000061F8 File Offset: 0x000043F8
		public static IntPtr StringToHeap(string src, Encoding encode)
		{
			bool flag = string.IsNullOrEmpty(src);
			IntPtr result;
			if (flag)
			{
				result = IntPtr.Zero;
			}
			else
			{
				bool flag2 = encode == null;
				if (flag2)
				{
					result = Marshal.StringToCoTaskMemAnsi(src);
				}
				else
				{
					int maxByteCount = encode.GetMaxByteCount(1);
					char[] array = src.ToCharArray();
					int num = encode.GetByteCount(array) + maxByteCount;
					byte[] array2 = new byte[0];
					array2 = new byte[num];
					bool flag3 = encode.GetBytes(array, 0, array.Length, array2, 0) != array2.Length - maxByteCount;
					if (flag3)
					{
						throw new NotSupportedException("StringToHeap编码不支持");
					}
					IntPtr intPtr = Marshal.AllocCoTaskMem(array2.Length);
					bool flag4 = intPtr == IntPtr.Zero;
					if (flag4)
					{
						throw new OutOfMemoryException();
					}
					bool flag5 = false;
					try
					{
						Marshal.Copy(array2, 0, intPtr, array2.Length);
						flag5 = true;
					}
					finally
					{
						bool flag6 = !flag5;
						if (flag6)
						{
							Marshal.FreeCoTaskMem(intPtr);
						}
					}
					result = intPtr;
				}
			}
			return result;
		}

		// Token: 0x0600018B RID: 395 RVA: 0x000062F4 File Offset: 0x000044F4
		public static bool WritePlist(IntPtr dataPtr, string fileOnPC)
		{
			bool flag = false;
			bool flag2 = dataPtr == IntPtr.Zero;
			bool result;
			if (flag2)
			{
				result = false;
			}
			else
			{
				IntPtr intPtr = IntPtr.Zero;
				try
				{
					intPtr = CoreFoundation.CFURLCreateWithFileSystemPath(CoreFoundation.kCFAllocatorDefault, CoreFoundation.StringToCFString(fileOnPC), CFURLPathStyle.kCFURLWindowsPathStyle, false);
					bool flag3 = intPtr != IntPtr.Zero;
					if (flag3)
					{
						IntPtr intPtr2 = CoreFoundation.CFPropertyListCreateXMLData(CoreFoundation.kCFAllocatorDefault, dataPtr);
						bool flag4 = intPtr2 != IntPtr.Zero;
						if (flag4)
						{
							IntPtr zero = IntPtr.Zero;
							int num = -1;
							flag = CoreFoundation.CFURLWriteDataAndPropertiesToResource(intPtr, intPtr2, zero, ref num);
							CoreFoundation.CFRelease(intPtr2);
						}
						else
						{
							flag = false;
						}
						CoreFoundation.CFRelease(intPtr);
						return flag;
					}
					flag = false;
				}
				catch 
				{
				}
				result = flag;
			}
			return result;
		}

		// Token: 0x0600018C RID: 396 RVA: 0x000063B8 File Offset: 0x000045B8
		public static bool WritePlist(object dict, string fileOnPC)
		{
			return CoreFoundation.WritePlist(CoreFoundation.CFTypeFromManagedType(dict), fileOnPC);
		}

		// Token: 0x040001B2 RID: 434
		public static IntPtr kCFAllocatorDefault = IntPtr.Zero;

		// Token: 0x040001B3 RID: 435
		public static IntPtr kCFBooleanFalse = IntPtr.Zero;

		// Token: 0x040001B4 RID: 436
		public static IntPtr kCFBooleanTrue = IntPtr.Zero;

		// Token: 0x040001B5 RID: 437
		public static IntPtr kCFStreamPropertyDataWritten = IntPtr.Zero;

		// Token: 0x040001B6 RID: 438
		public static IntPtr kCFTypeArrayCallBacks = IntPtr.Zero;

		// Token: 0x040001B7 RID: 439
		public static IntPtr kCFTypeDictionaryKeyCallBacks = IntPtr.Zero;

		// Token: 0x040001B8 RID: 440
		public static IntPtr kCFTypeDictionaryValueCallBacks = IntPtr.Zero;

		// Token: 0x040001B9 RID: 441
		private static int mBindDeviceGrappaFuncOffsetAddress = 0;

		// Token: 0x040001BA RID: 442
		private static int mCreateHostGrappaFuncOffsetAddress = 0;

		// Token: 0x040001BB RID: 443
		private static Dictionary<string, int> mDictiTunesDllOffset = null;

		// Token: 0x040001BC RID: 444
		private static int mFuncOffsetAddress = 0;

		// Token: 0x040001BD RID: 445
		private static int mGrappaID = 0;

		// Token: 0x040001BE RID: 446
		private static string AppleMobileDeviceSupportPath = string.Empty;
	}
}
