﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000021 RID: 33
	public enum CFStringEncoding
	{
		// Token: 0x04000128 RID: 296
		kCFStringEncodingANSEL = 1537,
		// Token: 0x04000129 RID: 297
		kCFStringEncodingASCII = 1536,
		// Token: 0x0400012A RID: 298
		kCFStringEncodingBig5 = 2563,
		// Token: 0x0400012B RID: 299
		kCFStringEncodingBig5_E = 2569,
		// Token: 0x0400012C RID: 300
		kCFStringEncodingBig5_HKSCS_1999 = 2566,
		// Token: 0x0400012D RID: 301
		kCFStringEncodingCNS_11643_92_P1 = 1617,
		// Token: 0x0400012E RID: 302
		kCFStringEncodingCNS_11643_92_P2,
		// Token: 0x0400012F RID: 303
		kCFStringEncodingCNS_11643_92_P3,
		// Token: 0x04000130 RID: 304
		kCFStringEncodingDOSArabic = 1049,
		// Token: 0x04000131 RID: 305
		kCFStringEncodingDOSBalticRim = 1030,
		// Token: 0x04000132 RID: 306
		kCFStringEncodingDOSCanadianFrench = 1048,
		// Token: 0x04000133 RID: 307
		kCFStringEncodingDOSChineseSimplif = 1057,
		// Token: 0x04000134 RID: 308
		kCFStringEncodingDOSChineseTrad = 1059,
		// Token: 0x04000135 RID: 309
		kCFStringEncodingDOSCyrillic = 1043,
		// Token: 0x04000136 RID: 310
		kCFStringEncodingDOSGreek = 1029,
		// Token: 0x04000137 RID: 311
		kCFStringEncodingDOSGreek1 = 1041,
		// Token: 0x04000138 RID: 312
		kCFStringEncodingDOSGreek2 = 1052,
		// Token: 0x04000139 RID: 313
		kCFStringEncodingDOSHebrew = 1047,
		// Token: 0x0400013A RID: 314
		kCFStringEncodingDOSIcelandic = 1046,
		// Token: 0x0400013B RID: 315
		kCFStringEncodingDOSJapanese = 1056,
		// Token: 0x0400013C RID: 316
		kCFStringEncodingDOSKorean = 1058,
		// Token: 0x0400013D RID: 317
		kCFStringEncodingDOSLatin1 = 1040,
		// Token: 0x0400013E RID: 318
		kCFStringEncodingDOSLatin2 = 1042,
		// Token: 0x0400013F RID: 319
		kCFStringEncodingDOSLatinUS = 1024,
		// Token: 0x04000140 RID: 320
		kCFStringEncodingDOSNordic = 1050,
		// Token: 0x04000141 RID: 321
		kCFStringEncodingDOSPortuguese = 1045,
		// Token: 0x04000142 RID: 322
		kCFStringEncodingDOSRussian = 1051,
		// Token: 0x04000143 RID: 323
		kCFStringEncodingDOSThai = 1053,
		// Token: 0x04000144 RID: 324
		kCFStringEncodingDOSTurkish = 1044,
		// Token: 0x04000145 RID: 325
		kCFStringEncodingEBCDIC_CP037 = 3074,
		// Token: 0x04000146 RID: 326
		kCFStringEncodingEBCDIC_US = 3073,
		// Token: 0x04000147 RID: 327
		kCFStringEncodingEUC_CN = 2352,
		// Token: 0x04000148 RID: 328
		kCFStringEncodingEUC_JP = 2336,
		// Token: 0x04000149 RID: 329
		kCFStringEncodingEUC_KR = 2368,
		// Token: 0x0400014A RID: 330
		kCFStringEncodingEUC_TW = 2353,
		// Token: 0x0400014B RID: 331
		kCFStringEncodingGB_18030_2000 = 1586,
		// Token: 0x0400014C RID: 332
		kCFStringEncodingGB_2312_80 = 1584,
		// Token: 0x0400014D RID: 333
		kCFStringEncodingGBK_95,
		// Token: 0x0400014E RID: 334
		kCFStringEncodingHZ_GB_2312 = 2565,
		// Token: 0x0400014F RID: 335
		kCFStringEncodingISO_2022_CN = 2096,
		// Token: 0x04000150 RID: 336
		kCFStringEncodingISO_2022_CN_EXT,
		// Token: 0x04000151 RID: 337
		kCFStringEncodingISO_2022_JP = 2080,
		// Token: 0x04000152 RID: 338
		kCFStringEncodingISO_2022_JP_1 = 2082,
		// Token: 0x04000153 RID: 339
		kCFStringEncodingISO_2022_JP_2 = 2081,
		// Token: 0x04000154 RID: 340
		kCFStringEncodingISO_2022_JP_3 = 2083,
		// Token: 0x04000155 RID: 341
		kCFStringEncodingISO_2022_KR = 2112,
		// Token: 0x04000156 RID: 342
		kCFStringEncodingISOLatin1 = 513,
		// Token: 0x04000157 RID: 343
		kCFStringEncodingISOLatin10 = 528,
		// Token: 0x04000158 RID: 344
		kCFStringEncodingISOLatin2 = 514,
		// Token: 0x04000159 RID: 345
		kCFStringEncodingISOLatin3,
		// Token: 0x0400015A RID: 346
		kCFStringEncodingISOLatin4,
		// Token: 0x0400015B RID: 347
		kCFStringEncodingISOLatin5 = 521,
		// Token: 0x0400015C RID: 348
		kCFStringEncodingISOLatin6,
		// Token: 0x0400015D RID: 349
		kCFStringEncodingISOLatin7 = 525,
		// Token: 0x0400015E RID: 350
		kCFStringEncodingISOLatin8,
		// Token: 0x0400015F RID: 351
		kCFStringEncodingISOLatin9,
		// Token: 0x04000160 RID: 352
		kCFStringEncodingISOLatinArabic = 518,
		// Token: 0x04000161 RID: 353
		kCFStringEncodingISOLatinCyrillic = 517,
		// Token: 0x04000162 RID: 354
		kCFStringEncodingISOLatinGreek = 519,
		// Token: 0x04000163 RID: 355
		kCFStringEncodingISOLatinHebrew,
		// Token: 0x04000164 RID: 356
		kCFStringEncodingISOLatinThai = 523,
		// Token: 0x04000165 RID: 357
		kCFStringEncodingJIS_C6226_78 = 1572,
		// Token: 0x04000166 RID: 358
		kCFStringEncodingJIS_X0201_76 = 1568,
		// Token: 0x04000167 RID: 359
		kCFStringEncodingJIS_X0208_83,
		// Token: 0x04000168 RID: 360
		kCFStringEncodingJIS_X0208_90,
		// Token: 0x04000169 RID: 361
		kCFStringEncodingJIS_X0212_90,
		// Token: 0x0400016A RID: 362
		kCFStringEncodingKOI8_R = 2562,
		// Token: 0x0400016B RID: 363
		kCFStringEncodingKOI8_U = 2568,
		// Token: 0x0400016C RID: 364
		kCFStringEncodingKSC_5601_87 = 1600,
		// Token: 0x0400016D RID: 365
		kCFStringEncodingKSC_5601_92_Johab,
		// Token: 0x0400016E RID: 366
		kCFStringEncodingMacArabic = 4,
		// Token: 0x0400016F RID: 367
		kCFStringEncodingMacArmenian = 24,
		// Token: 0x04000170 RID: 368
		kCFStringEncodingMacBengali = 13,
		// Token: 0x04000171 RID: 369
		kCFStringEncodingMacBurmese = 19,
		// Token: 0x04000172 RID: 370
		kCFStringEncodingMacCeltic = 39,
		// Token: 0x04000173 RID: 371
		kCFStringEncodingMacCentralEurRoman = 29,
		// Token: 0x04000174 RID: 372
		kCFStringEncodingMacChineseSimp = 25,
		// Token: 0x04000175 RID: 373
		kCFStringEncodingMacChineseTrad = 2,
		// Token: 0x04000176 RID: 374
		kCFStringEncodingMacCroatian = 36,
		// Token: 0x04000177 RID: 375
		kCFStringEncodingMacCyrillic = 7,
		// Token: 0x04000178 RID: 376
		kCFStringEncodingMacDevanagari = 9,
		// Token: 0x04000179 RID: 377
		kCFStringEncodingMacDingbats = 34,
		// Token: 0x0400017A RID: 378
		kCFStringEncodingMacEthiopic = 28,
		// Token: 0x0400017B RID: 379
		kCFStringEncodingMacExtArabic = 31,
		// Token: 0x0400017C RID: 380
		kCFStringEncodingMacFarsi = 140,
		// Token: 0x0400017D RID: 381
		kCFStringEncodingMacGaelic = 40,
		// Token: 0x0400017E RID: 382
		kCFStringEncodingMacGeorgian = 23,
		// Token: 0x0400017F RID: 383
		kCFStringEncodingMacGreek = 6,
		// Token: 0x04000180 RID: 384
		kCFStringEncodingMacGujarati = 11,
		// Token: 0x04000181 RID: 385
		kCFStringEncodingMacGurmukhi = 10,
		// Token: 0x04000182 RID: 386
		kCFStringEncodingMacHebrew = 5,
		// Token: 0x04000183 RID: 387
		kCFStringEncodingMacHFS = 255,
		// Token: 0x04000184 RID: 388
		kCFStringEncodingMacIcelandic = 37,
		// Token: 0x04000185 RID: 389
		kCFStringEncodingMacInuit = 236,
		// Token: 0x04000186 RID: 390
		kCFStringEncodingMacJapanese = 1,
		// Token: 0x04000187 RID: 391
		kCFStringEncodingMacKannada = 16,
		// Token: 0x04000188 RID: 392
		kCFStringEncodingMacKhmer = 20,
		// Token: 0x04000189 RID: 393
		kCFStringEncodingMacKorean = 3,
		// Token: 0x0400018A RID: 394
		kCFStringEncodingMacLaotian = 22,
		// Token: 0x0400018B RID: 395
		kCFStringEncodingMacMalayalam = 17,
		// Token: 0x0400018C RID: 396
		kCFStringEncodingMacMongolian = 27,
		// Token: 0x0400018D RID: 397
		kCFStringEncodingMacOriya = 12,
		// Token: 0x0400018E RID: 398
		kCFStringEncodingMacRoman = 0,
		// Token: 0x0400018F RID: 399
		kCFStringEncodingMacRomanian = 38,
		// Token: 0x04000190 RID: 400
		kCFStringEncodingMacRomanLatin1 = 2564,
		// Token: 0x04000191 RID: 401
		kCFStringEncodingMacSinhalese = 18,
		// Token: 0x04000192 RID: 402
		kCFStringEncodingMacSymbol = 33,
		// Token: 0x04000193 RID: 403
		kCFStringEncodingMacTamil = 14,
		// Token: 0x04000194 RID: 404
		kCFStringEncodingMacTelugu,
		// Token: 0x04000195 RID: 405
		kCFStringEncodingMacThai = 21,
		// Token: 0x04000196 RID: 406
		kCFStringEncodingMacTibetan = 26,
		// Token: 0x04000197 RID: 407
		kCFStringEncodingMacTurkish = 35,
		// Token: 0x04000198 RID: 408
		kCFStringEncodingMacUkrainian = 152,
		// Token: 0x04000199 RID: 409
		kCFStringEncodingMacVietnamese = 30,
		// Token: 0x0400019A RID: 410
		kCFStringEncodingMacVT100 = 252,
		// Token: 0x0400019B RID: 411
		kCFStringEncodingNextStepJapanese = 2818,
		// Token: 0x0400019C RID: 412
		kCFStringEncodingNextStepLatin = 2817,
		// Token: 0x0400019D RID: 413
		kCFStringEncodingShiftJIS = 2561,
		// Token: 0x0400019E RID: 414
		kCFStringEncodingShiftJIS_X0213 = 1576,
		// Token: 0x0400019F RID: 415
		kCFStringEncodingShiftJIS_X0213_00 = 1576,
		// Token: 0x040001A0 RID: 416
		kCFStringEncodingShiftJIS_X0213_MenKuTen,
		// Token: 0x040001A1 RID: 417
		kCFStringEncodingUTF7 = 67109120,
		// Token: 0x040001A2 RID: 418
		kCFStringEncodingUTF7_IMAP = 2576,
		// Token: 0x040001A3 RID: 419
		kCFStringEncodingVISCII = 2567,
		// Token: 0x040001A4 RID: 420
		kCFStringEncodingWindowsArabic = 1286,
		// Token: 0x040001A5 RID: 421
		kCFStringEncodingWindowsBalticRim,
		// Token: 0x040001A6 RID: 422
		kCFStringEncodingWindowsCyrillic = 1282,
		// Token: 0x040001A7 RID: 423
		kCFStringEncodingWindowsGreek,
		// Token: 0x040001A8 RID: 424
		kCFStringEncodingWindowsHebrew = 1285,
		// Token: 0x040001A9 RID: 425
		kCFStringEncodingWindowsKoreanJohab = 1296,
		// Token: 0x040001AA RID: 426
		kCFStringEncodingWindowsLatin1 = 1280,
		// Token: 0x040001AB RID: 427
		kCFStringEncodingWindowsLatin2,
		// Token: 0x040001AC RID: 428
		kCFStringEncodingWindowsLatin5 = 1284,
		// Token: 0x040001AD RID: 429
		kCFStringEncodingWindowsVietnamese = 1288
	}
}
