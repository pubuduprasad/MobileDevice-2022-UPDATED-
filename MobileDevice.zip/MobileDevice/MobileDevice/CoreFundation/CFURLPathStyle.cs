﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000022 RID: 34
	internal enum CFURLPathStyle
	{
		// Token: 0x040001AF RID: 431
		kCFURLPOSIXPathStyle,
		// Token: 0x040001B0 RID: 432
		kCFURLHFSPathStyle,
		// Token: 0x040001B1 RID: 433
		kCFURLWindowsPathStyle
	}
}
