﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000025 RID: 37
	[StructLayout(LayoutKind.Sequential)]
	public class SECURITY_ATTRIBUTES
	{
		// Token: 0x040001C3 RID: 451
		public int nLength;

		// Token: 0x040001C4 RID: 452
		public string lpSecurityDescriptor;

		// Token: 0x040001C5 RID: 453
		public bool bInheritHandle;
	}
}
