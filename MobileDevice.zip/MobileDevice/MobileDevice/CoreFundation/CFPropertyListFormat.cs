﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x0200001D RID: 29
	internal enum CFPropertyListFormat
	{
		// Token: 0x0400011C RID: 284
		kCFPropertyListBinaryFormat_v1_0 = 200,
		// Token: 0x0400011D RID: 285
		kCFPropertyListOpenStepFormat = 1,
		// Token: 0x0400011E RID: 286
		kCFPropertyListXMLFormat_v1_0 = 100
	}
}
