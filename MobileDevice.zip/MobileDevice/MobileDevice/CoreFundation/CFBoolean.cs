﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using MobileDevice.Helper;

namespace MobileDevice.CoreFundation
{
	// Token: 0x0200001A RID: 26
	public class CFBoolean
	{
		// Token: 0x06000110 RID: 272
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x06000111 RID: 273
		[DllImport("kernel32.dll")]
		public static extern IntPtr LoadLibrary(string lpFileName);

		// Token: 0x06000112 RID: 274
		[DllImport("kernel32.dll")]
		public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

		// Token: 0x06000113 RID: 275 RVA: 0x00004B1C File Offset: 0x00002D1C
		public static IntPtr GetCFBoolean(bool flag)
		{
			string lpProcName = flag ? "kCFBooleanTrue" : "kCFBooleanFalse";
			IntPtr intPtr = CFBoolean.GetModuleHandle("CoreFoundation.dll");
			bool flag2 = intPtr == IntPtr.Zero;
			if (flag2)
			{
				string appleApplicationSupportFolder = DLLHelper.GetAppleApplicationSupportFolder();
				bool flag3 = !string.IsNullOrWhiteSpace(appleApplicationSupportFolder);
				if (flag3)
				{
					intPtr = CFBoolean.LoadLibrary(Path.Combine(appleApplicationSupportFolder, "CoreFoundation.dll"));
				}
			}
			IntPtr ptr = IntPtr.Zero;
			bool flag4 = intPtr != IntPtr.Zero;
			if (flag4)
			{
				ptr = CFBoolean.GetProcAddress(intPtr, lpProcName);
			}
			return Marshal.ReadIntPtr(ptr, 0);
		}
	}
}
