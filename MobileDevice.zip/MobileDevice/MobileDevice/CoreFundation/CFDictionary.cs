﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x0200001B RID: 27
	internal class CFDictionary : IDisposable
	{
		// Token: 0x06000115 RID: 277 RVA: 0x00004BB0 File Offset: 0x00002DB0
		internal CFDictionary(IntPtr handle, bool owns)
		{
			bool flag = handle == IntPtr.Zero;
			if (flag)
			{
				throw new ArgumentNullException("handle");
			}
			this._handle = handle;
			bool flag2 = !owns;
			if (flag2)
			{
				CoreFoundation.CFRetain(handle);
			}
		}

		// Token: 0x06000116 RID: 278 RVA: 0x00004BF8 File Offset: 0x00002DF8
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000117 RID: 279 RVA: 0x00004C0C File Offset: 0x00002E0C
		protected virtual void Dispose(bool disposing)
		{
			bool flag = this._handle != IntPtr.Zero;
			if (flag)
			{
				CoreFoundation.CFRelease(this._handle);
				this._handle = IntPtr.Zero;
			}
		}

		// Token: 0x06000118 RID: 280 RVA: 0x00004C48 File Offset: 0x00002E48
		~CFDictionary()
		{
			this.Dispose(false);
		}

		// Token: 0x06000119 RID: 281 RVA: 0x00004C7C File Offset: 0x00002E7C
		internal static void GetKeysAndValues(IntPtr srcRef, IntPtr keys, ref IntPtr values)
		{
			CoreFoundation.CFDictionaryGetKeysAndValues(srcRef, keys, values);
		}

		// Token: 0x04000108 RID: 264
		internal IntPtr _handle;
	}
}
