﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000024 RID: 36
	public struct PROCESS_INFORMATION
	{
		// Token: 0x17000026 RID: 38
		// (get) Token: 0x0600018E RID: 398 RVA: 0x000063D8 File Offset: 0x000045D8
		public bool IsEmpty
		{
			get
			{
				return this.hProcess == IntPtr.Zero && this.hThread == IntPtr.Zero && this.dwProcessId == 0 && this.dwThreadId == 0;
			}
		}

		// Token: 0x040001BF RID: 447
		public IntPtr hProcess;

		// Token: 0x040001C0 RID: 448
		public IntPtr hThread;

		// Token: 0x040001C1 RID: 449
		public int dwProcessId;

		// Token: 0x040001C2 RID: 450
		public int dwThreadId;
	}
}
