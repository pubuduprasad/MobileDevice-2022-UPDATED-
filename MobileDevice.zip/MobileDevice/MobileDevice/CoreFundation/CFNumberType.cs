﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x0200001C RID: 28
	public enum CFNumberType
	{
		// Token: 0x0400010A RID: 266
		kCFNumberSInt8Type = 1,
		// Token: 0x0400010B RID: 267
		kCFNumberSInt16Type,
		// Token: 0x0400010C RID: 268
		kCFNumberSInt32Type,
		// Token: 0x0400010D RID: 269
		kCFNumberSInt64Type,
		// Token: 0x0400010E RID: 270
		kCFNumberFloat32Type,
		// Token: 0x0400010F RID: 271
		kCFNumberFloat64Type,
		// Token: 0x04000110 RID: 272
		kCFNumberCharType,
		// Token: 0x04000111 RID: 273
		kCFNumberShortType,
		// Token: 0x04000112 RID: 274
		kCFNumberIntType,
		// Token: 0x04000113 RID: 275
		kCFNumberLongType,
		// Token: 0x04000114 RID: 276
		kCFNumberLongLongType,
		// Token: 0x04000115 RID: 277
		kCFNumberFloatType,
		// Token: 0x04000116 RID: 278
		kCFNumberDoubleType,
		// Token: 0x04000117 RID: 279
		kCFNumberCFIndexType,
		// Token: 0x04000118 RID: 280
		kCFNumberNSIntegerType,
		// Token: 0x04000119 RID: 281
		kCFNumberCGFloatType,
		// Token: 0x0400011A RID: 282
		kCFNumberMaxType = 16
	}
}
