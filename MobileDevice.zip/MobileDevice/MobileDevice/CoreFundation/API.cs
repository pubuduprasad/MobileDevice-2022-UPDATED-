﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000019 RID: 25
	public class API
	{
		// Token: 0x06000107 RID: 263
		[DllImport("kernel32.dll")]
		public static extern bool CloseHandle(IntPtr hObject);

		// Token: 0x06000108 RID: 264
		[DllImport("kernel32.dll")]
		public static extern bool CreatePipe(ref IntPtr hReadPipe, ref IntPtr hWritePipe, SECURITY_ATTRIBUTES lpPipeAttributes, int nSize);

		// Token: 0x06000109 RID: 265
		[DllImport("kernel32.dll")]
		public static extern bool CreateProcess(string lpApplicationName, string lpCommandLine, SECURITY_ATTRIBUTES lpProcessAttributes, SECURITY_ATTRIBUTES lpThreadAttributes, bool bInheritHandles, int dwCreationFlags, string lpEnvironment, string lpCurrentDirectory, ref STARTUPINFO lpStartupInfo, ref PROCESS_INFORMATION lpProcessInformation);

		// Token: 0x0600010A RID: 266
		[DllImport("kernel32.dll")]
		public static extern bool FreeLibrary(IntPtr hModule);

		// Token: 0x0600010B RID: 267 RVA: 0x00004AE8 File Offset: 0x00002CE8
		public static Delegate GetAddress(IntPtr dllModule, string functionName, Type t)
		{
			IntPtr procAddress = API.GetProcAddress(dllModule, functionName);
			bool flag = procAddress == IntPtr.Zero;
			Delegate result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = Marshal.GetDelegateForFunctionPointer(procAddress, t);
			}
			return result;
		}

		// Token: 0x0600010C RID: 268
		[DllImport("kernel32.dll")]
		public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

		// Token: 0x0600010D RID: 269
		[DllImport("kernel32.dll")]
		public static extern IntPtr LoadLibrary(string lpFileName);

		// Token: 0x0600010E RID: 270
		[DllImport("kernel32.dll")]
		public static extern bool ReadFile(IntPtr hFile, byte[] lpBuffer, int nNumberOfBytesToRead, ref int lpNumberOfBytesRead, IntPtr lpOverlapped);

		// Token: 0x040000EF RID: 239
		public const int NORMAL_PRIORITY_CLASS = 32;

		// Token: 0x040000F0 RID: 240
		public const int STARTF_FORCEOFFFEEDBACK = 128;

		// Token: 0x040000F1 RID: 241
		public const int STARTF_FORCEONFEEDBACK = 64;

		// Token: 0x040000F2 RID: 242
		public const int STARTF_RUNFULLSCREEN = 32;

		// Token: 0x040000F3 RID: 243
		public const int STARTF_USECOUNTCHARS = 8;

		// Token: 0x040000F4 RID: 244
		public const int STARTF_USEFILLATTRIBUTE = 16;

		// Token: 0x040000F5 RID: 245
		public const int STARTF_USEPOSITION = 4;

		// Token: 0x040000F6 RID: 246
		public const int STARTF_USESHOWWINDOW = 1;

		// Token: 0x040000F7 RID: 247
		public const int STARTF_USESIZE = 2;

		// Token: 0x040000F8 RID: 248
		public const int STARTF_USESTDHANDLES = 256;

		// Token: 0x040000F9 RID: 249
		public const int SW_FORCEMINIMIZE = 11;

		// Token: 0x040000FA RID: 250
		public const int SW_HIDE = 0;

		// Token: 0x040000FB RID: 251
		public const int SW_MAX = 11;

		// Token: 0x040000FC RID: 252
		public const int SW_MAXIMIZE = 3;

		// Token: 0x040000FD RID: 253
		public const int SW_MINIMIZE = 6;

		// Token: 0x040000FE RID: 254
		public const int SW_NORMAL = 1;

		// Token: 0x040000FF RID: 255
		public const int SW_RESTORE = 9;

		// Token: 0x04000100 RID: 256
		public const int SW_SHOW = 5;

		// Token: 0x04000101 RID: 257
		public const int SW_SHOWDEFAULT = 10;

		// Token: 0x04000102 RID: 258
		public const int SW_SHOWMAXIMIZED = 3;

		// Token: 0x04000103 RID: 259
		public const int SW_SHOWMINIMIZED = 2;

		// Token: 0x04000104 RID: 260
		public const int SW_SHOWMINNOACTIVE = 7;

		// Token: 0x04000105 RID: 261
		public const int SW_SHOWNA = 8;

		// Token: 0x04000106 RID: 262
		public const int SW_SHOWNOACTIVATE = 4;

		// Token: 0x04000107 RID: 263
		public const int SW_SHOWNORMAL = 1;

		// Token: 0x0200002E RID: 46
		// (Invoke) Token: 0x060001A8 RID: 424
		public delegate bool Close();

		// Token: 0x0200002F RID: 47
		// (Invoke) Token: 0x060001AC RID: 428
		public delegate bool Decode(string sourceFileMp3, string destFileWav);

		// Token: 0x02000030 RID: 48
		// (Invoke) Token: 0x060001B0 RID: 432
		public delegate bool Encode(string sourceFileWav, string destFileMp3);

		// Token: 0x02000031 RID: 49
		// (Invoke) Token: 0x060001B4 RID: 436
		public delegate int GetDecodePercent();

		// Token: 0x02000032 RID: 50
		// (Invoke) Token: 0x060001B8 RID: 440
		public delegate double GetLValue(double secondTime);

		// Token: 0x02000033 RID: 51
		// (Invoke) Token: 0x060001BC RID: 444
		public delegate int GetPercent();

		// Token: 0x02000034 RID: 52
		// (Invoke) Token: 0x060001C0 RID: 448
		public delegate bool Open(string fileWavName);

		// Token: 0x02000035 RID: 53
		// (Invoke) Token: 0x060001C4 RID: 452
		public delegate bool Split(string fileWavOut, double begin, double end, double in_time, double out_time);
	}
}
