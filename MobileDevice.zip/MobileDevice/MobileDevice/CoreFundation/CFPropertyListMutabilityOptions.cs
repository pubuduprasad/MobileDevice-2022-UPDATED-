﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x0200001E RID: 30
	internal enum CFPropertyListMutabilityOptions
	{
		// Token: 0x04000120 RID: 288
		kCFPropertyListImmutable,
		// Token: 0x04000121 RID: 289
		kCFPropertyListMutableContainers,
		// Token: 0x04000122 RID: 290
		kCFPropertyListMutableContainersAndLeaves
	}
}
