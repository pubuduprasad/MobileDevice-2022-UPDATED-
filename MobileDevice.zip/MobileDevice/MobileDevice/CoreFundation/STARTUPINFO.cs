﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000026 RID: 38
	public struct STARTUPINFO
	{
		// Token: 0x040001C6 RID: 454
		public int cb;

		// Token: 0x040001C7 RID: 455
		public string lpReserved;

		// Token: 0x040001C8 RID: 456
		public string lpDesktop;

		// Token: 0x040001C9 RID: 457
		public int lpTitle;

		// Token: 0x040001CA RID: 458
		public int dwX;

		// Token: 0x040001CB RID: 459
		public int dwY;

		// Token: 0x040001CC RID: 460
		public int dwXSize;

		// Token: 0x040001CD RID: 461
		public int dwYSize;

		// Token: 0x040001CE RID: 462
		public int dwXCountChars;

		// Token: 0x040001CF RID: 463
		public int dwYCountChars;

		// Token: 0x040001D0 RID: 464
		public int dwFillAttribute;

		// Token: 0x040001D1 RID: 465
		public int dwFlags;

		// Token: 0x040001D2 RID: 466
		public int wShowWindow;

		// Token: 0x040001D3 RID: 467
		public int cbReserved2;

		// Token: 0x040001D4 RID: 468
		public byte lpReserved2;

		// Token: 0x040001D5 RID: 469
		public IntPtr hStdInput;

		// Token: 0x040001D6 RID: 470
		public IntPtr hStdOutput;

		// Token: 0x040001D7 RID: 471
		public IntPtr hStdError;
	}
}
