﻿using System;
using System.Runtime.InteropServices;

namespace MobileDevice.CoreFundation
{
	// Token: 0x02000020 RID: 32
	internal class CFString : IDisposable
	{
		// Token: 0x0600011B RID: 283 RVA: 0x00004C9C File Offset: 0x00002E9C
		internal CFString(IntPtr handle) : this(handle, false)
		{
		}

		// Token: 0x0600011C RID: 284 RVA: 0x00004CA8 File Offset: 0x00002EA8
		internal CFString(string str)
		{
			bool flag = str == null;
			if (flag)
			{
				throw new ArgumentNullException("str");
			}
			this._handle = CoreFoundation.CFStringCreateWithCharacters(IntPtr.Zero, str, str.Length);
			this._str = str;
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00004CF0 File Offset: 0x00002EF0
		internal CFString(IntPtr handle, bool owns)
		{
			this._handle = handle;
			bool flag = !owns;
			if (flag)
			{
				CoreFoundation.CFRetain(handle);
			}
		}

		// Token: 0x0600011E RID: 286 RVA: 0x00004D1D File Offset: 0x00002F1D
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00004D30 File Offset: 0x00002F30
		protected virtual void Dispose(bool disposing)
		{
			this._str = null;
			bool flag = this._handle != IntPtr.Zero;
			if (flag)
			{
				CoreFoundation.CFRelease(this._handle);
				this._handle = IntPtr.Zero;
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x00004D74 File Offset: 0x00002F74
		public override bool Equals(object other)
		{
			CFString cfstring = other as CFString;
			bool flag = cfstring == null;
			return !flag && cfstring.Handle == this._handle;
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00004DB0 File Offset: 0x00002FB0
		internal unsafe static string FetchString(IntPtr handle)
		{
			bool flag = handle == IntPtr.Zero;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int num = CoreFoundation.CFStringGetLength(handle);
				IntPtr intPtr = CoreFoundation.CFStringGetCharactersPtr(handle);
				IntPtr intPtr2 = IntPtr.Zero;
				bool flag2 = intPtr == IntPtr.Zero;
				if (flag2)
				{
					CFRange range = new CFRange(0, num);
					intPtr2 = Marshal.AllocCoTaskMem(num * 2);
					CoreFoundation.CFStringGetCharacters(handle, range, intPtr2);
					intPtr = intPtr2;
				}
				result = new string((char*)((void*)intPtr), 0, num);
			}
			return result;
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00004E2C File Offset: 0x0000302C
		~CFString()
		{
			this.Dispose(false);
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00004E60 File Offset: 0x00003060
		public override int GetHashCode()
		{
			return this._handle.GetHashCode();
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00004E80 File Offset: 0x00003080
		public static bool operator ==(CFString a, CFString b)
		{
			return object.Equals(a, b);
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00004E9C File Offset: 0x0000309C
		public static implicit operator string(CFString other)
		{
			bool flag = string.IsNullOrEmpty(other._str);
			if (flag)
			{
				other._str = CFString.FetchString(other._handle);
			}
			return other._str;
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00004ED8 File Offset: 0x000030D8
		public static implicit operator CFString(string s)
		{
			return new CFString(s);
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00004EF0 File Offset: 0x000030F0
		public static bool operator !=(CFString a, CFString b)
		{
			return !object.Equals(a, b);
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x06000128 RID: 296 RVA: 0x00004F0C File Offset: 0x0000310C
		public IntPtr Handle
		{
			get
			{
				return this._handle;
			}
		}

		// Token: 0x17000024 RID: 36
		public char this[int p]
		{
			get
			{
				bool flag = this._str != null;
				char result;
				if (flag)
				{
					result = this._str[p];
				}
				else
				{
					result = CoreFoundation.CFStringGetCharacterAtIndex(this._handle, p);
				}
				return result;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x0600012A RID: 298 RVA: 0x00004F60 File Offset: 0x00003160
		internal int Length
		{
			get
			{
				bool flag = this._str != null;
				int result;
				if (flag)
				{
					result = this._str.Length;
				}
				else
				{
					result = CoreFoundation.CFStringGetLength(this._handle);
				}
				return result;
			}
		}

		// Token: 0x04000125 RID: 293
		internal IntPtr _handle;

		// Token: 0x04000126 RID: 294
		internal string _str;
	}
}
