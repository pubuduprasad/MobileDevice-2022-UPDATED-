﻿using System;

namespace MobileDevice.CoreFundation
{
	// Token: 0x0200001F RID: 31
	internal struct CFRange
	{
		// Token: 0x0600011A RID: 282 RVA: 0x00004C89 File Offset: 0x00002E89
		internal CFRange(int l, int len)
		{
			this.Location = (long)l;
			this.Length = (long)len;
		}

		// Token: 0x04000123 RID: 291
		internal long Location;

		// Token: 0x04000124 RID: 292
		internal long Length;
	}
}
